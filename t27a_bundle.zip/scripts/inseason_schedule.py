"""2026-27 NBA regular-season schedule as flat tables for in-season management.

Source: nba_api ScheduleLeagueV2 (cdn.nba.com static JSON returns 403 from this machine, the stats endpoint works).
Cached at data/raw/schedule_2026-27.json; call refresh() to re-pull (the NBA reschedules a few games every season).

Fantasy weeks are Monday-Sunday (league scoring period). Outputs
  games()            one row per (team, game): date, team, opp, home, weekday, week_start, b2b
  week_table(week)   games per team per day for one Mon-Sun week (rows teams, columns Mon..Sun, 0/1)
  weeks()            list of Monday dates that contain regular-season games
"""
import json
import sys
from pathlib import Path

import pandas as pd

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "data" / "raw" / "schedule_2026-27.json"
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def refresh():
    import truststore
    truststore.inject_into_ssl()
    from nba_api.stats.endpoints import scheduleleaguev2
    j = scheduleleaguev2.ScheduleLeagueV2(season="2026-27", timeout=90).get_dict()
    CACHE.write_text(json.dumps(j))
    return j


def _load():
    return json.loads(CACHE.read_text()) if CACHE.exists() else refresh()


OVERLAY = ROOT / "data" / "live" / "schedule_overlay.json"
OVERLAY_DAYS, OVERLAY_MAX_AGE_H = 21, 6
_MEMO = {}


def _overlay_rows():
    """ESPN's view of the next 3 weeks (adds the NBA Cup games the NBA has not published, catches postponements). Cached 6 hours."""
    import time
    from datetime import date, datetime, timedelta
    try:
        c = json.loads(OVERLAY.read_text(encoding="utf-8")) if OVERLAY.exists() else None
    except Exception:
        c = None
    if c and time.time() - c["t"] < OVERLAY_MAX_AGE_H * 3600:
        return c["rows"]
    try:
        import espn_site as ES
        d0 = max(date(2026, 10, 20), (datetime.utcnow() - timedelta(hours=8)).date())
        d1 = d0 + timedelta(days=OVERLAY_DAYS)
        rows = [[r[0].isoformat(), r[1], r[2], r[3], r[4], r[5].isoformat()] for r in ES.schedule_rows(d0, d1)]
        OVERLAY.parent.mkdir(parents=True, exist_ok=True)
        OVERLAY.write_text(json.dumps({"t": time.time(), "rows": rows, "d0": d0.isoformat(), "d1": d1.isoformat()}), encoding="utf-8")
        return rows
    except Exception as e:
        print("schedule overlay unavailable:", type(e).__name__, str(e)[:80])
        return c["rows"] if c else []


def games(include_preseason=False, overlay=True) -> pd.DataFrame:
    key = (include_preseason, overlay, CACHE.stat().st_mtime if CACHE.exists() else 0, int(__import__("time").time() // 600))
    if key in _MEMO:
        return _MEMO[key]
    df = _games(include_preseason)
    if overlay:
        rows = _overlay_rows()
        if rows:
            ov = pd.DataFrame(rows, columns=["date", "team", "opp", "home", "game_id", "tip_utc"])
            ov["date"], ov["tip_utc"] = pd.to_datetime(ov["date"]), pd.to_datetime(ov["tip_utc"])
            lo, hi = ov["date"].min(), ov["date"].max()
            df = df[~((df["date"] >= lo) & (df["date"] <= hi) & df["game_id"].astype(str).str.startswith("002"))]
            ov["weekday"] = ov["date"].dt.weekday
            ov["week_start"] = ov["date"] - pd.to_timedelta(ov["weekday"], unit="D")
            df = pd.concat([df, ov.assign(b2b=False)], ignore_index=True).sort_values(["team", "date"]).reset_index(drop=True)
            prev = df.groupby("team")["date"].shift(1)
            df["b2b"] = (df["date"] - prev).dt.days == 1
    _MEMO.clear()
    _MEMO[key] = df
    return df


def _games(include_preseason=False) -> pd.DataFrame:
    rows = []
    for gd in _load()["leagueSchedule"]["gameDates"]:
        for g in gd["games"]:
            if not include_preseason and not str(g["gameId"]).startswith("002"):
                continue
            d = pd.Timestamp(g["gameDateEst"][:10])
            h, a = g["homeTeam"]["teamTricode"], g["awayTeam"]["teamTricode"]
            tip = pd.Timestamp(g["gameDateTimeUTC"]).tz_localize(None) if g.get("gameDateTimeUTC") else pd.NaT
            rows.append((d, h, a, True, g["gameId"], tip))
            rows.append((d, a, h, False, g["gameId"], tip))
    df = pd.DataFrame(rows, columns=["date", "team", "opp", "home", "game_id", "tip_utc"])
    df = df[df["team"].str.len() == 3].sort_values(["team", "date"]).reset_index(drop=True)
    df["weekday"] = df["date"].dt.weekday
    df["week_start"] = df["date"] - pd.to_timedelta(df["weekday"], unit="D")
    prev = df.groupby("team")["date"].shift(1)
    df["b2b"] = (df["date"] - prev).dt.days == 1
    return df


def weeks(df=None):
    df = games() if df is None else df
    return sorted(df["week_start"].unique())


def week_table(week_start, df=None) -> pd.DataFrame:
    df = games() if df is None else df
    w = df[df["week_start"] == pd.Timestamp(week_start)]
    t = w.pivot_table(index="team", columns="weekday", values="game_id", aggfunc="count", fill_value=0)
    t = t.reindex(columns=range(7), fill_value=0)
    t.columns = DAYS
    return t


if __name__ == "__main__":
    df = games()
    print("regular-season games per team:", df.groupby("team").size().describe()[["min", "max"]].to_dict())
    print("first/last regular-season date:", df["date"].min().date(), df["date"].max().date())
    ws = weeks(df)
    print("weeks:", len(ws), "first Monday", pd.Timestamp(ws[0]).date(), "last", pd.Timestamp(ws[-1]).date())
    first = week_table(ws[0], df)
    print("week 1 games per team (min/max):", first.sum(axis=1).min(), first.sum(axis=1).max(), "| days with games:",
          first.sum().to_dict())
    per_wk = df.groupby(["week_start", "team"]).size().unstack(0)
    print("games/team/week distribution:\n", per_wk.stack().value_counts().sort_index().to_string())
