"""Live in-season engine for the New Lapis Lapis League (ESPN 127741): daily H2H prediction + streaming recommendations.

build_state() -> dict (JSON-serialisable) used by lapis_app.py. Pipeline:
  1. ESPN (public league, no login): rosters, this matchup's live totals (incl. FGM/FGA/FTA/3PA and GP = counted starts),
     today's lineup, free agents (+ waiver status/date), adds used this week (transactionCounter.matchupAcquisitionTotals)
  2. projections in RAW per-game stats: pool_2026-27_v31 z-scores converted back with the 2025-26 draftable-pool mean/sd
     (attempts for the % categories from last season's per-game volume); players outside the pool fall back to last season x0.92
  3. start plan per team via inseason_allocator (7 slots/day with positions, weekly cap, Sunday rule), only for games not yet tipped
  4. totals = ESPN actuals so far + planned starts x P(play); variance = real weekly noise (gh_core.TAU) + did-he-play noise
  5. per-category win probability (delta method for the % cats), matchup win = P(>= 7 of 13), day-by-day path
  6. streaming: every add/drop pair from the free-agent pool vs. the weakest players on the roster, ranked by change in P(win)

Known limits (shown in the app too): P(play) is a flat 0.90 for ACTIVE players (0.5 DTD, 0 OUT) until in-season minutes exist;
projections are preseason until games are played (no in-season blending yet); opponent is assumed to start its best lineup;
categories are treated as independent; week 18 (two-week matchup) cap/limits are an ASSUMPTION until the user confirms them.
"""
import json
import re
import sys
import unicodedata
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gh_core as G  # noqa: E402
import inseason_allocator as A  # noqa: E402
import inseason_schedule as SCH  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import league_cfg as LC  # noqa: E402

ROOT = G.ROOT
LEAGUE_ID, YEAR, MY_TEAM = LC.LEAGUE_ID, LC.YEAR, LC.MY_TEAM
LIVE = LC.LIVE                         # league-specific state folder (snapshots, move log, predictions)
SEASON_START = LC.SEASON_START
CATS = G.CATS13
LABEL = {"pts": "PTS", "stl": "STL", "blk": "BLK", "oreb": "OREB", "dreb": "DREB", "fg_pct": "FG%", "3pm": "3PM", "3p_pct": "3P%",
         "ftm": "FTM", "ft_pct": "FT%", "to": "TO", "pf": "PF", "ast": "AST"}
COMP = ["pts", "stl", "blk", "oreb", "dreb", "3pm", "ftm", "to", "pf", "ast", "fgm", "fga", "3pa", "fta"]
CI = {c: i for i, c in enumerate(COMP)}
COUNTING = ["pts", "stl", "blk", "oreb", "dreb", "3pm", "ftm", "ast", "to", "pf"]
LOWER_BETTER = {"to", "pf"}
PCT = {"fg_pct": ("fgm", "fga"), "3p_pct": ("3pm", "3pa"), "ft_pct": ("ftm", "fta")}
ESPN_STAT = {"pts": "PTS", "stl": "STL", "blk": "BLK", "oreb": "OREB", "dreb": "DREB", "3pm": "3PM", "ftm": "FTM", "to": "TO",
             "pf": "PF", "ast": "AST", "fgm": "FGM", "fga": "FGA", "3pa": "3PA", "fta": "FTA"}
ALIAS = {"PHL": "PHI", "PHO": "PHX", "NO": "NOP", "NY": "NYK", "SA": "SAS", "GS": "GSW", "WSH": "WAS", "UTAH": "UTA"}
POS_ID = {0: "PG", 1: "SG", 2: "SF", 3: "PF", 4: "C"}
P_ACTIVE, P_DTD = 0.90, 0.50
LAST_SEASON_SHRINK = 0.92
DEFAULT_CAP, DEFAULT_ADDS = A.CAP, LC.C["adds"]
WEEK_CAP = dict(LC.C["week_cap"])
WEEK_ADDS = dict(LC.C["week_adds"])
LONG_WEEKS = set(LC.C["long_weeks"])  # two-week matchups (All-Star break; T27A also has two-week playoff rounds): limits assumed doubled
SUN_CAP = A.SUN_CAP
HAS_CAP = LC.HAS_CAP
N_TEAMS = LC.C["n_teams"]


WIN_SHRINK = 0.90    # backtest_winprob.py (7,140 matchups, 4 seasons): recalibration slope of the matchup win chance = 0.906 (a bit too extreme)


def calib_win(p, a=WIN_SHRINK):
    """Display-only: pull the matchup win chance slightly toward 50% (logistic slope `a`). Lineup and streaming choices use the raw value."""
    p = float(np.clip(p, 1e-4, 1 - 1e-4))
    z = a * np.log(p / (1 - p))
    return float(1 / (1 + np.exp(-z)))


def jclean(o):
    """Make a state dict safe for browsers: NaN / infinity (which JSON.parse rejects) become null, numpy scalars become Python ones."""
    if isinstance(o, dict):
        return {str(k): jclean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple, set)):
        return [jclean(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (float, np.floating)):
        f = float(o)
        return f if np.isfinite(f) else None
    if isinstance(o, (date, datetime)):
        return o.isoformat()
    return o


# ---------------------------------------------------------------- calendar
def period_bounds(mp):
    """Matchup period -> (first date, last date), from the league config (week 1 = Tue Oct 20 - Sun Oct 25, weeks 2-17 Mon-Sun, week 18 = Feb 15-28)."""
    return LC.C["period_fn"](mp)


def period_of(d):
    n = LC.C["n_periods"]
    for mp in range(1, n + 1):
        a, b = period_bounds(mp)
        if a <= d <= b:
            return mp
    return n if d > period_bounds(n)[1] else 1


def now_nba(now=None):
    """Current moment as (UTC naive datetime, NBA 'day' date). The scoring day rolls over ~8h behind UTC."""
    n = (now or datetime.now(timezone.utc)).astimezone(timezone.utc).replace(tzinfo=None)
    return n, (n - timedelta(hours=8)).date()


def norm(s):
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower()
    s = re.sub(r"\b(jr|sr|ii|iii|iv)\b\.?", "", s)
    return re.sub(r"[^a-z]", "", s)


def tri(abbr):
    return ALIAS.get(abbr, abbr)


# ---------------------------------------------------------------- projections
def q_constants(season="2025-26"):
    """Draftable-pool (Q) mean / sd of per-game stats exactly as percat.season_zq defines them."""
    import percat as PC
    df = pd.read_csv(ROOT / "data" / "raw" / "long" / f"players_{season}.csv")
    pool = df[(df["GP"] >= 20) & (df["MIN"] >= 15)].copy()
    z1 = pd.DataFrame(index=pool.index)
    for c, col in PC.COUNT.items():
        z1[c] = (pool[col] - pool[col].mean()) / pool[col].std()
    for c, (a, b) in PC.PCT.items():
        comp = pool[a].sum() / pool[b].sum()
        imp = pool[a] - comp * pool[b]
        z1[c] = (imp - imp.mean()) / imp.std()
    z1[["to", "pf"]] *= -1
    Q = pool.loc[z1.sum(axis=1).sort_values(ascending=False).head(PC.Q_SIZE).index]
    q = {"mean": {}, "sd": {}, "comp": {}, "imp_mean": {}, "imp_sd": {}}
    for c, col in PC.COUNT.items():
        q["mean"][c], q["sd"][c] = float(Q[col].mean()), float(Q[col].std())
    for c, (a, b) in PC.PCT.items():
        comp = Q[a].sum() / Q[b].sum()
        imp = Q[a] - comp * Q[b]
        q["comp"][c], q["imp_mean"][c], q["imp_sd"][c] = float(comp), float(imp.mean()), float(imp.std())
    return q, df


Q, LAST = q_constants()
LAST_IDX = LAST.assign(k=LAST["PLAYER_NAME"].map(norm)).drop_duplicates("k").set_index("k")


def raw_from_row(g):
    """Last-season per-game stats -> raw component vector."""
    return np.array([g["PTS"], g["STL"], g["BLK"], g["OREB"], g["DREB"], g["FG3M"], g["FTM"], g["TOV"], g["PF"], g["AST"],
                     g["FGM"], g["FGA"], g["FG3A"], g["FTA"]], dtype=float)


def raw_from_z(z, fga):
    """pool z-scores (13 cats, CATS order) -> raw component vector. fga = expected FG attempts per game."""
    zz = dict(zip(CATS, z))
    r = np.zeros(14)
    for c in ("pts", "stl", "blk", "oreb", "dreb", "3pm", "ftm", "ast"):
        r[CI[c]] = max(Q["mean"][c] + Q["sd"][c] * zz[c], 0.0)
    for c in ("to", "pf"):
        r[CI[c]] = max(Q["mean"][c] - Q["sd"][c] * zz[c], 0.0)
    imp = Q["imp_mean"]["fg_pct"] + Q["imp_sd"]["fg_pct"] * zz["fg_pct"]
    r[CI["fga"]] = fga
    r[CI["fgm"]] = float(np.clip(Q["comp"]["fg_pct"] * fga + imp, 0.2 * fga, 0.9 * fga))
    for pc, made in (("3p_pct", "3pm"), ("ft_pct", "ftm")):
        imp = Q["imp_mean"][pc] + Q["imp_sd"][pc] * zz[pc]
        att = (r[CI[made]] - imp) / Q["comp"][pc]
        lo = r[CI[made]] / (0.5 if pc == "3p_pct" else 1.0)
        hi = r[CI[made]] / (0.2 if pc == "3p_pct" else 0.4)
        r[CI["3pa" if pc == "3p_pct" else "fta"]] = float(np.clip(att, lo if pc == "ft_pct" else r[CI[made]], max(hi, 0.1)))
    return r


def sigma_units(r):
    """Absolute contribution of one started game in sigma units (empty slot = 0): counting r/sd, TO/PF negative, % cats impact/sd."""
    u = np.zeros(13)
    for i, c in enumerate(CATS):
        if c in PCT:
            made, att = PCT[c]
            imp = r[CI[made]] - Q["comp"][c] * r[CI[att]]
            u[i] = imp / Q["imp_sd"][c]
        else:
            u[i] = (-1 if c in LOWER_BETTER else 1) * r[CI[c]] / Q["sd"][c]
    return u


BLEND_K = 14.0     # games of "prior weight": research_inseason_blend.py, walk-forward 2022-26 -> next-10 error 1.51 vs 1.67 (prior only) / 1.75 (games only)
AVAIL_PRIOR_GAMES = 6
_OBS, _AVAIL, _MPG = {}, {}, {}
_OBS_COLS = ["PTS", "STL", "BLK", "OREB", "DREB", "FG3M", "FTM", "TOV", "PF", "AST", "FGM", "FGA", "FG3A", "FTA"]    # same order as COMP


def load_obs():
    """Real 2026-27 per-game averages (blend with the projection) and real play rates, from the stored regular-season ESPN box lines."""
    global _OBS, _AVAIL, _MPG
    _OBS, _AVAIL, _MPG = {}, {}, {}
    f = ROOT / "data" / "live" / "season_lines.csv"
    if not f.exists():
        return
    d = pd.read_csv(f)
    d["k"] = d["PLAYER_NAME"].map(norm)
    mg = d.groupby("k")["MIN"].agg(["mean", "size"])
    _MPG = {k: float(r["mean"]) for k, r in mg.iterrows() if r["size"] >= 5}      # this season's typical minutes (for who counts as a rotation absence)
    ok = d[d["MIN"] >= 8]
    g = ok.groupby("k")
    n, m = g.size(), g[_OBS_COLS].mean()
    _OBS = {k: (int(n[k]), m.loc[k].to_numpy(dtype=float)) for k in n.index}
    # play rate while healthy: games he appeared in over his team's last 15 games (shrunk toward the 90% prior)
    team_games = d.groupby("TEAM_ABBREVIATION")["GAME_ID"].apply(lambda s: list(dict.fromkeys(s))[-15:])
    last_team = d.sort_values("GAME_DATE").groupby("k")["TEAM_ABBREVIATION"].last()
    for k, t in last_team.items():
        tg = team_games.get(t, [])
        if len(tg) >= 3:
            played = d[(d["k"] == k) & d["GAME_ID"].isin(tg) & (d["MIN"] > 0)]["GAME_ID"].nunique()
            _AVAIL[k] = float(np.clip((played + P_ACTIVE * AVAIL_PRIOR_GAMES) / (len(tg) + AVAIL_PRIOR_GAMES), 0.45, 0.97))


def blend_obs(k, r):
    if k in _OBS:
        n, o = _OBS[k]
        w = n / (n + BLEND_K)
        return w * o + (1 - w) * r
    return r


def load_projections():
    load_obs()
    pool = pd.read_csv(ROOT / "data" / "pool_2026-27_v31.csv").drop_duplicates("PLAYER_NAME")
    out = {}
    for _, row in pool.iterrows():
        k = norm(row["PLAYER_NAME"])
        fga = float(LAST_IDX.loc[k, "FGA"]) if k in LAST_IDX.index else 8.0
        out[k] = {"name": row["PLAYER_NAME"], "r": blend_obs(k, raw_from_z(row[[f"z_{c}" for c in CATS]].to_numpy(dtype=float), fga)),
                  "src": "model" + (f" + {_OBS[k][0]} games" if k in _OBS else ""), "tier": row.get("durability_risk_tier", None)}
    return out


def fallback_projection(name):
    k = norm(name)
    if k in LAST_IDX.index:
        g = LAST_IDX.loc[k]
        if g["GP"] >= 10 and g["MIN"] >= 10:
            return {"name": name, "r": blend_obs(k, raw_from_row(g) * LAST_SEASON_SHRINK),
                    "src": "last season x0.92" + (f" + {_OBS[k][0]} games" if k in _OBS else ""), "tier": None}
    if k in _OBS and _OBS[k][0] >= 3:                                     # rookie / new player with real games but no history
        return {"name": name, "r": _OBS[k][1] * 0.85, "src": f"{_OBS[k][0]} games only x0.85", "tier": None}
    return None


# ---------------------------------------------------------------- ESPN
def pull_espn(mp, sp, d0):
    from espn_api.basketball.constant import PRO_TEAM_MAP
    lg = LC.open_league()
    teams = {}
    for t in lg.teams:
        teams[t.team_id] = {"id": t.team_id, "name": t.team_name, "owner": (t.owners[0].get("displayName") if t.owners else ""),
                            "roster": [{"id": p.playerId, "name": p.name, "team": tri(p.proTeam), "inj": p.injuryStatus,
                                        "elig": [s for s in p.eligibleSlots if s in A.POS], "slot": p.lineupSlot} for p in t.roster]}
    # matchup live totals + current lineup
    box = None
    try:
        for b in lg.box_scores(matchup_period=mp, scoring_period=sp, matchup_total=True):
            if MY_TEAM in (b.home_team.team_id, getattr(b.away_team, "team_id", None)):
                box = b
                break
    except Exception as e:
        print("box_scores failed:", type(e).__name__, e)
    res = {"teams": teams, "box": None, "lineup": {}, "lg": lg}
    if box is not None:
        mine_home = box.home_team.team_id == MY_TEAM
        res["opp_id"] = box.away_team.team_id if mine_home else box.home_team.team_id
        st_me, st_op = (box.home_stats, box.away_stats) if mine_home else (box.away_stats, box.home_stats)
        res["box"] = {"me": st_me, "opp": st_op}
    try:
        for b in lg.box_scores(matchup_period=mp, scoring_period=sp, matchup_total=False):
            for side in ("home", "away"):
                team = getattr(b, f"{side}_team")
                if team and team.team_id in (MY_TEAM, res.get("opp_id")):
                    res["lineup"][team.team_id] = {p.playerId: p.lineupSlot for p in getattr(b, f"{side}_lineup")}
    except Exception as e:
        print("lineup failed:", type(e).__name__, e)
    mt = lg.espn_request.league_get(params={"view": "mTeam"})["teams"]
    me = next(t for t in mt if t["id"] == MY_TEAM)
    res["adds_used"] = int(me.get("transactionCounter", {}).get("matchupAcquisitionTotals", {}).get(str(mp), 0))
    res["adds_hist"] = {t["id"]: {int(k): int(v) for k, v in (t.get("transactionCounter", {}).get("matchupAcquisitionTotals", {}) or {}).items()}
                        for t in mt}
    # free agents (raw endpoint; espn_api's own free_agents() does not sort the way we need)
    filt = {"players": {"filterStatus": {"value": ["FREEAGENT", "WAIVERS"]}, "filterSlotIds": {"value": list(range(0, 15))},
                        "limit": 400, "sortPercOwned": {"sortPriority": 1, "sortAsc": False}}}
    fa = lg.espn_request.league_get(params={"view": "kona_player_info"}, headers={"x-fantasy-filter": json.dumps(filt)})["players"]
    res["fa"] = []
    for x in fa:
        p = x["player"]
        wd = x.get("waiverProcessDate")
        res["fa"].append({"id": p["id"], "name": p["fullName"], "team": tri(PRO_TEAM_MAP.get(p.get("proTeamId"), "FA")),
                          "inj": p.get("injuryStatus", "ACTIVE"), "status": x["status"],
                          "waiver_date": (datetime.fromtimestamp(wd / 1000, timezone.utc) - timedelta(hours=8)).date().isoformat() if wd else None,
                          "elig": [POS_ID[s] for s in p.get("eligibleSlots", []) if s in POS_ID],
                          "own": round(p.get("ownership", {}).get("percentOwned", 0.0), 1)})
    return res


# ---------------------------------------------------------------- team engine
def p_play(inj, days_ahead=0, base=None):
    """Chance he plays if started. `base` = his real play rate when healthy (0.90 until games exist). A day-to-day tag matters for
    tonight and tomorrow, much less for games a week away."""
    base = P_ACTIVE if base is None else base
    s = str(inj or "ACTIVE").upper()
    if s in ("OUT", "SUSPENSION", "INJURY_RESERVE"):
        return 0.0
    if s in ("DAY_TO_DAY", "QUESTIONABLE", "DOUBTFUL"):
        f = P_DTD if days_ahead <= 0 else (0.65 if days_ahead == 1 else 0.80)
        return min(base, f * base / P_ACTIVE)
    return base


def mk_player(rec, proj):
    r = proj["r"]
    base = _AVAIL.get(norm(rec["name"]))
    return {"name": rec["name"], "team": rec["team"], "elig": set(rec["elig"]) or set(A.POS), "p": p_play(rec.get("inj"), 0, base),
            "base": base, "ret": rec.get("ret"), "news": rec.get("news"),
            "r": r, "u": sigma_units(r), "src": proj["src"], "inj": rec.get("inj", "ACTIVE"), "id": rec.get("id"),
            "avail_from": rec.get("avail_from")}


def enrich_injuries(recs, feed):
    """Attach ESPN's injury feed (status, detail, return date, newest comment) to player records. If ESPN's fantasy status still says
    ACTIVE but the injury feed says Out / Day-To-Day (fantasy status lags), the feed wins."""
    for r in recs:
        f = feed.get(norm(r["name"]))
        if not f:
            continue
        fs = str(f["status"]).upper()
        if str(r.get("inj") or "ACTIVE").upper() == "ACTIVE":
            if fs.startswith("OUT"):
                r["inj"] = "OUT"
            elif fs.startswith("DAY"):
                r["inj"] = "DAY_TO_DAY"
        r["news"] = {"status": f["status"], "fantasy": f["fantasy"], "detail": f["detail"], "ret": f["ret"], "comment": f["comment"], "date": f["date"]}
        if f["ret"]:
            try:
                r["ret"] = date.fromisoformat(str(f["ret"])[:10])
            except ValueError:
                pass


INJ_SNAP = LIVE / "injury_snapshot.json"


def injury_alerts(rosters, fa, my_id, opp_id, now_ts):
    """Status / return-date changes since the last refresh for my roster, my opponent's, and the most-owned free agents."""
    try:
        prev = json.loads(INJ_SNAP.read_text(encoding="utf-8-sig"))
    except Exception:
        prev = None
    cur, who = {}, {}
    for tid, recs in rosters.items():
        for r in recs:
            k = norm(r["name"])
            cur[k] = [str(r.get("inj") or "ACTIVE"), str(r.get("ret") or "")]
            who[k] = ("you" if tid == my_id else "opp" if tid == opp_id else "other", r)
    for r in sorted(fa, key=lambda x: -(x.get("own") or 0))[:100]:
        k = norm(r["name"])
        cur.setdefault(k, [str(r.get("inj") or "ACTIVE"), str(r.get("ret") or "")])
        who.setdefault(k, ("FA", r))
    alerts = []
    if prev:
        for k, v in cur.items():
            o = prev.get("s", {}).get(k)
            if o is not None and o != v and who[k][0] != "other":
                where, r = who[k]
                alerts.append({"name": r["name"], "where": where, "team": r["team"], "old": o[0], "new": v[0], "ret": v[1] or None,
                               "detail": (r.get("news") or {}).get("detail", ""), "comment": (r.get("news") or {}).get("comment", ""),
                               "ts": now_ts})
    INJ_SNAP.parent.mkdir(parents=True, exist_ok=True)
    INJ_SNAP.write_text(json.dumps({"ts": now_ts, "s": cur}), encoding="utf-8")
    rank = {"you": 0, "opp": 1, "FA": 2}
    return sorted(alerts, key=lambda a: rank.get(a["where"], 3))


class Week:
    """One matchup period: day indexes, schedule per team, and the lock state at `now`."""

    def __init__(self, mp, now_utc, today, real_today=None):
        self.mp = mp
        self.real_today = real_today or today
        self.start, self.end = period_bounds(mp)
        self.n = (self.end - self.start).days + 1
        self.today_idx = max(0, min(self.n - 1, (today - self.start).days)) if today >= self.start else 0
        self.finished = today > self.end
        sch = SCH.games()
        sch = sch[(sch["date"].dt.date >= self.start) & (sch["date"].dt.date <= self.end)].copy()
        sch["idx"] = (sch["date"].dt.date - self.start).map(lambda x: x.days)
        sch["started"] = sch["tip_utc"] <= pd.Timestamp(now_utc)
        self.sch = sch
        self.sun = (self.n - 1 if self.end.weekday() == 6 else None) if HAS_CAP else None     # no cap = no special Sunday
        self.cap = WEEK_CAP.get(mp, DEFAULT_CAP * (2 if mp in LONG_WEEKS else 1))
        self.adds = WEEK_ADDS.get(mp, DEFAULT_ADDS)
        self.assumed = mp in LONG_WEEKS

    def play_days(self, open_from=None):
        """team -> set of day idx with a game still to tip (today's started games are already in the ESPN totals)."""
        if getattr(self, "_pd", None) is None:                       # the schedule does not change inside a build: compute once (was ~40% of build time)
            o = {}
            for r in self.sch.itertuples():
                if r.idx < self.today_idx or (r.idx == self.today_idx and r.started):
                    continue
                o.setdefault(r.team, set()).add(int(r.idx))
            self._pd = o
        return self._pd

    def games_left(self, team):
        return len(self.play_days().get(team, ()))


def day_p(inj, ret, base, day, real_today):
    """Chance a player plays on `day`: status + days ahead, his real play rate, and ESPN's return date (no games before it, a shaky first
    game on it, his normal rate after it; an OUT tag with no return date means out for the whole horizon)."""
    pp = p_play(inj, (day - real_today).days, base)
    if ret:
        b = P_ACTIVE if base is None else base
        return 0.0 if day < ret else (min(0.6, b) if day == ret else b)
    if str(inj or "ACTIVE").upper() in ("OUT", "SUSPENSION", "INJURY_RESERVE"):
        return 0.0
    return pp


# ---- teammates' absences: absence_boost.json (research_absence_boost.py, 2021-26): stat = base * (1 + k * m), m = vacated minutes / 240
_ABSJ = ROOT / "data" / "research" / "absence_boost.json"
ABS_K, ABS_M_CAP, ABS_ROT_MPG = np.zeros(14), 0.40, 18.0
if _ABSJ.exists():
    _a = json.loads(_ABSJ.read_text())
    ABS_K = np.array([max(0.0, _a["k"][c]) if _a["k"][c] > 2 * _a["se"][c] else 0.0 for c in _OBS_COLS])     # only effects clearly above noise (steals, blocks drop out)
    ABS_M_CAP = float(_a.get("m_cap", ABS_M_CAP))
ABS_KAPPA = float(ABS_K[0])                    # points coefficient: scales how valuable a start is when teammates are out
ABSENT = {}                                    # team -> rotation players currently listed out / day-to-day: {name, key, mpg, inj, ret}


def set_absences(feed):
    global ABSENT
    ABSENT = {}
    for k, f in feed.items():
        s = str(f["status"]).upper()
        inj = "OUT" if (s.startswith("OUT") or "SUSP" in s) else ("DAY_TO_DAY" if s.startswith("DAY") else None)
        mpg = _MPG.get(k)
        if mpg is None and k in LAST_IDX.index:
            mpg = float(LAST_IDX.loc[k, "MIN"])
        if inj is None or mpg is None or mpg < ABS_ROT_MPG:
            continue
        ret = None
        if f.get("ret"):
            try:
                ret = date.fromisoformat(str(f["ret"])[:10])
            except ValueError:
                pass
        ABSENT.setdefault(f["team"], []).append({"name": f["name"], "key": k, "mpg": mpg, "inj": inj, "ret": ret})


def absence_m(team, key, day, real_today):
    """m for a player on `team` on `day`: probability-weighted minutes of listed-out rotation teammates / 240, and who they are."""
    m, who = 0.0, []
    for y in ABSENT.get(team, ()):
        if y["key"] == key:
            continue
        po = 1.0 - day_p(y["inj"], y["ret"], None, day, real_today)
        if po > 0.05:
            m += po * y["mpg"] / 240.0
            who.append((y["name"], round(po, 2)))
    return min(m, ABS_M_CAP), who


def team_pack(players, wk, actual, weights, buffer=1.0):
    """Plan starts and aggregate expected totals / variance for one team over the rest of the week."""
    gp = float(actual.get("GP", {}).get("value", 0.0)) if actual else 0.0
    over = gp > wk.cap
    cap_rem = max(0.0, wk.cap - gp)
    pl, absm = {}, {}
    pdays = dict(wk.play_days())
    for p in players:
        val = float((p["u"] * weights).sum() / G_AVG)
        pday, vday, mult = {}, {}, {}
        key = norm(p["name"])
        for d in range(wk.n):
            day = wk.start + timedelta(days=d)
            pday[d] = day_p(p["inj"], p.get("ret"), p.get("base"), day, wk.real_today)
            m, _ = absence_m(p["team"], key, day, wk.real_today)
            if m > 0.01:                                              # teammates out: more minutes and usage for him that day
                mult[d] = 1.0 + ABS_K * m
                vday[d] = val * (1.0 + ABS_KAPPA * m)
        if mult:
            absm[p["name"]] = mult
        pl[p["name"]] = {"elig": p["elig"], "value": val, "p": p["p"], "pday": pday, "vday": vday, "team": p["team"]}
        lo, hi = 0, 10 ** 6                                          # waiver-locked pickups / streaming windows: games only inside [lo, hi]
        if p.get("avail_from"):
            lo = max(lo, (date.fromisoformat(p["avail_from"]) - wk.start).days)
        if p.get("win"):
            lo, hi = max(lo, p["win"][0]), min(hi, p["win"][1])
        if lo > 0 or hi < 10 ** 6:
            k2 = p["team"] + "|" + p["name"]
            pdays[k2] = {d for d in pdays.get(p["team"], ()) if lo <= d <= hi}
            pl[p["name"]]["team"] = k2
    open_days = range(wk.today_idx, wk.n)
    plan = A.plan_week(pl, pdays, weeks_days=open_days, cap=cap_rem, sun_cap=SUN_CAP, buffer=buffer, n_days=wk.n,
                       sun_day=wk.sun if wk.sun is not None else -1, sunday_open=not over)
    by = {p["name"]: p for p in players}
    return {"plan": plan, "by": by, "actual": actual, "gp": gp, "weights": weights, "absm": absm}


def aggregate(pack, upto=None):
    """Expected total vector (14) and per-component variance for starts with day <= upto (None = all) plus ESPN actuals."""
    tot, var = np.zeros(14), np.zeros(13)
    act = pack["actual"] or {}
    for c in COMP:
        tot[CI[c]] += float(act.get(ESPN_STAT[c], {}).get("value", 0.0))
    absm = pack.get("absm", {})
    for name, d, _, p in pack["plan"]["starts"]:
        if upto is not None and d > upto:
            continue
        r = pack["by"][name]["r"]
        if name in absm and d in absm[name]:                          # his teammates are out that day
            r = r * absm[name][d]
        tot += p * r
        for i, c in enumerate(CATS):
            if c in PCT:
                made, att = PCT[c]
                x = r[CI[made]] - Q["comp"][c] * r[CI[att]]
                base = Q["imp_sd"][c]
            else:
                x, base = r[CI[c]], Q["sd"][c]
            var[i] += p * G.TAU[i] ** 2 * G_AVG * base ** 2 + p * (1 - p) * x * x
    return tot, var


def cat_values(tot):
    out = {}
    for c in CATS:
        if c in PCT:
            made, att = PCT[c]
            out[c] = tot[CI[made]] / tot[CI[att]] if tot[CI[att]] > 0 else 0.0
        else:
            out[c] = tot[CI[c]]
    return out


def evaluate(t_me, v_me, t_op, v_op):
    """Per-category win probability for me and P(win >= 7 of 13)."""
    pc = np.zeros(13)
    for i, c in enumerate(CATS):
        if c in PCT:
            made, att = PCT[c]
            a_me, a_op = max(t_me[CI[att]], 1e-9), max(t_op[CI[att]], 1e-9)
            mean = t_me[CI[made]] / a_me - t_op[CI[made]] / a_op
            sd = np.sqrt(v_me[i] / a_me ** 2 + v_op[i] / a_op ** 2)
        else:
            mean = t_me[CI[c]] - t_op[CI[c]]
            sd = np.sqrt(v_me[i] + v_op[i])
        if c in LOWER_BETTER:
            mean = -mean
        pc[i] = float(G.cdf(mean / sd)) if sd > 1e-9 else (1.0 if mean > 1e-9 else (0.0 if mean < -1e-9 else 0.5))
    dp = np.zeros(14); dp[0] = 1.0
    for p in pc:
        nxt = dp * (1 - p); nxt[1:] += dp[:-1] * p
        dp = nxt
    return pc, float(dp[7:].sum())


G_AVG = 3.21
BAL = G.RATIO.copy()                  # balanced category weights (G-score reliability ratios)


def matchup_eval(pk_me, pk_op, upto=None):
    t1, v1 = aggregate(pk_me, upto)
    t2, v2 = aggregate(pk_op, upto)
    pc, pw = evaluate(t1, v1, t2, v2)
    return pc, pw, t1, t2


def optimise_weights(me, op_pack, wk, actual, base_w, passes=2):
    w = base_w.copy()
    best_pk = team_pack(me, wk, actual, w)
    _, best, *_ = matchup_eval(best_pk, op_pack)
    for _ in range(passes):
        changed = False
        for i in range(13):
            for lv in (1.0, 0.5, 0.0):
                t = w.copy(); t[i] = base_w[i] * lv
                if np.allclose(t, w):
                    continue
                pk = team_pack(me, wk, actual, t)
                _, pw, *_ = matchup_eval(pk, op_pack)
                if pw > best + 1e-4:
                    best, w, best_pk, changed = pw, t, pk, True
        if not changed:
            break
    return w, best_pk, best


# ---------------------------------------------------------------- streaming
def streaming(me, opp_pack, wk, actual, weights, fa_players, adds_left, base_pw, base_cats=0.0, base_pc=None, base_vals=None,
              k_drop=6, k_fa=70):
    """Best add/drop swaps for the rest of the week. Returns ranked list of dicts."""
    if adds_left <= 0 or wk.finished:
        return []
    base_pk = team_pack(me, wk, actual, weights)
    base_val = {p["name"]: 0.0 for p in me}
    # marginal expected value of each current player (drop candidates = least valuable, plus OUT players)
    for p in me:
        rest = [q for q in me if q["name"] != p["name"]]
        _, pw, *_ = matchup_eval(team_pack(rest, wk, actual, weights), opp_pack)
        base_val[p["name"]] = base_pw - pw
    drops = sorted(me, key=lambda p: (base_val[p["name"]], p["name"]))[:k_drop]
    pdays = wk.play_days()
    cand = []
    for f in fa_players:
        left = [d for d in pdays.get(f["team"], ()) if not f.get("avail_from") or d >= (date.fromisoformat(f["avail_from"]) - wk.start).days]
        if f["p"] <= 0 or not left:
            continue
        cand.append((float((f["u"] * weights).sum()) * f["p"] * len(left), f))
    cand = [f for _, f in sorted(cand, key=lambda x: -x[0])[:k_fa]]
    rows = []
    for f in cand:
        for d in drops:
            roster = [q for q in me if q["name"] != d["name"]] + [f]
            pc, pw, t1, t2 = matchup_eval(team_pack(roster, wk, actual, weights), opp_pack)
            va = cat_values(t1)
            eff = [{"cat": LABEL[c], "dp": float(pc[i] - base_pc[i]), "dproj": float(va[c] - base_vals[c]), "lower_better": c in LOWER_BETTER}
                   for i, c in enumerate(CATS)] if base_pc is not None else []
            helps = sorted([e for e in eff if e["dp"] >= 0.01], key=lambda e: -e["dp"])
            hurts = sorted([e for e in eff if e["dp"] <= -0.01], key=lambda e: e["dp"])
            rr, rd = f["r"], d["r"]
            line = lambda r: {"pts": r[CI["pts"]], "reb": r[CI["oreb"]] + r[CI["dreb"]], "ast": r[CI["ast"]], "stl": r[CI["stl"]],
                              "blk": r[CI["blk"]], "tpm": r[CI["3pm"]], "to": r[CI["to"]], "pf": r[CI["pf"]],
                              "fg": r[CI["fgm"]] / r[CI["fga"]] if r[CI["fga"]] else 0.0, "ft": r[CI["ftm"]] / r[CI["fta"]] if r[CI["fta"]] else 0.0}
            rows.append({"helps": helps, "hurts": hurts, "add_line": line(rr), "drop_line": line(rd), "add": f["name"], "add_team": f["team"], "add_pos": "/".join(sorted(f["elig"], key=list(A.POS).index if False else str)),
                         "add_inj": f["inj"], "add_status": f.get("status"), "add_wait": f.get("avail_from"), "drop": d["name"],
                         "boost": (_boost_text(f["team"], f["name"], wk.start + timedelta(days=min(pdays[f["team"]])), wk.real_today)
                                   if pdays.get(f["team"]) else None),
                         "d_pwin": pw - base_pw, "d_cats": float(pc.sum()) - base_cats, "pwin": pw, "games_left": len(pdays.get(f["team"], ())), "own": f.get("own"),
                         "src": f["src"]})
    rows.sort(key=lambda x: -(x["d_pwin"] + 0.02 * x["d_cats"]))     # P(win) saturates near 0/1, so expected categories break ties
    return rows


# ---------------------------------------------------------------- opponent streaming
def opp_propensity(hist, mp, prior=0.5, prior_weight=2):
    """How much of their add allowance a manager actually uses: mean of used/limit over PAST matchup periods (ESPN's per-period
    acquisition counter), shrunk toward `prior` so one quiet or busy week does not decide it. Week 1 (no history) = the prior."""
    fr = [min(1.0, hist.get(p, 0) / WEEK_ADDS.get(p, DEFAULT_ADDS)) for p in range(1, mp)]
    return float((sum(fr) + prior * prior_weight) / (len(fr) + prior_weight))


def opp_best_response(opp, my_pack, wk, act_op, fa_pl, adds_left, max_swaps=3):
    """Greedy: the swap that most raises THEIR win chance against my lineup, applied up to min(adds left, 3) times (the same free agent
    cannot be taken twice). It is what a sharp opponent would do; opp_propensity says how much weight to give it."""
    roster, moves, taken = list(opp), [], set()
    for _ in range(min(adds_left, max_swaps)):
        pk = team_pack(roster, wk, act_op, BAL)
        pc0, pw0, t0, _ = matchup_eval(pk, my_pack)
        pool = [f for f in fa_pl if f["name"] not in taken]
        rows = streaming(roster, my_pack, wk, act_op, BAL, pool, 99, pw0, float(pc0.sum()), pc0, cat_values(t0), k_drop=4, k_fa=35)
        if not rows or rows[0]["d_pwin"] < 0.004:
            break
        r = rows[0]
        add = next(f for f in pool if f["name"] == r["add"])
        roster = [q for q in roster if q["name"] != r["drop"]] + [add]
        taken.add(r["add"])
        moves.append({"add": r["add"], "drop": r["drop"], "d_pwin": r["d_pwin"], "helps": [e["cat"] for e in r["helps"][:3]]})
    return roster, moves


# ---------------------------------------------------------------- state
_BOX_KEY = {"PTS": "PTS", "STL": "STL", "BLK": "BLK", "AST": "AST", "TO": "TOV", "PF": "PF", "FGM": "FGM", "FGA": "FGA", "FTM": "FTM",
            "FTA": "FTA", "3PM": "FG3M", "3PA": "FG3A", "OREB": "OREB", "DREB": "DREB"}
_BENCH = {"BE", "IR", None, ""}


def apply_espn_lag(E, mp, today, opp_id):
    """ESPN posts a finished day's stats to the matchup hours after the games end (seen 2026-10-21: day-1 totals still 0 about 9 h later).
    Until then the engine would drop that day twice (its games are no longer 'to come' and ESPN's total has none of them), which understated
    both sides and moved the win chance. For every finished day whose ESPN day total is still empty, add what the public box scores say the
    starting slots produced (same rule ESPN uses: slot not on the bench, minutes > 0). Returns the days patched; a no-op once ESPN catches up."""
    if not E.get("box") or not E.get("lg"):
        return []
    import espn_site as ES
    patched = []
    start, _ = period_bounds(mp)
    for d in (today - timedelta(days=1), today):
        if d < max(start, SEASON_START):
            continue
        try:
            res = ES.box_lines(d)
            if not res["lines"] or not res["all_final"]:
                continue
            by = {norm(x["PLAYER_NAME"]): x for x in res["lines"]}
            for b in E["lg"].box_scores(matchup_period=mp, scoring_period=(d - SEASON_START).days + 1, matchup_total=False):
                for side in ("home", "away"):
                    team = getattr(b, f"{side}_team")
                    tid = getattr(team, "team_id", None)
                    if tid not in (MY_TEAM, opp_id):
                        continue
                    played = [by[norm(p.name)] for p in getattr(b, f"{side}_lineup")
                              if p.lineupSlot not in _BENCH and norm(p.name) in by and by[norm(p.name)]["MIN"] > 0]
                    espn_gp = float((getattr(b, f"{side}_stats") or {}).get("GP", {}).get("value", 0.0))
                    if not played or espn_gp >= len(played):
                        continue                                          # nothing to add, or ESPN already counted this day
                    tot = E["box"]["me" if tid == MY_TEAM else "opp"]
                    for k, bk in _BOX_KEY.items():
                        tot[k] = {"value": float(tot.get(k, {}).get("value", 0.0)) + sum(x[bk] for x in played)}
                    tot["GP"] = {"value": float(tot.get("GP", {}).get("value", 0.0)) + len(played)}
                    patched.append((d.isoformat(), "me" if tid == MY_TEAM else "opp", len(played)))
        except Exception as ex:
            print("espn-lag patch failed:", type(ex).__name__, ex)
    return patched


def build_state(now=None, espn=None):
    now_utc, today = now_nba(now)
    pre = today < SEASON_START
    mp = period_of(max(today, SEASON_START))
    wk = Week(mp, now_utc, max(today, SEASON_START) if pre else today, real_today=today)
    if pre:
        wk.today_idx = 0
        wk.sch["started"] = False
    sp = (max(today, SEASON_START) - SEASON_START).days + 1
    E = espn or pull_espn(mp, sp, today)
    build_state.last_espn = E
    proj = load_projections()
    warnings = []
    try:
        import espn_site as ES
        inj_feed = ES.injuries()
    except Exception as ex:
        inj_feed = {}
        warnings.append(f"injury feed unavailable ({type(ex).__name__}); using ESPN fantasy statuses only")
    set_absences(inj_feed)                                           # teammates who are out change everyone else's expected usage
    for t in E["teams"].values():
        enrich_injuries(t["roster"], inj_feed)
    enrich_injuries(E["fa"], inj_feed)

    def players_of(recs, tag=""):
        out = []
        for rec in recs:
            pr = proj.get(norm(rec["name"])) or fallback_projection(rec["name"])
            if pr is None:
                warnings.append(f"no projection for {rec['name']} ({rec['team']}); skipped")
                continue
            out.append(mk_player(rec, pr))
        return out

    me_rec = E["teams"][MY_TEAM]
    opp_id = E.get("opp_id") or _opp_from_schedule(E, mp)
    op_rec = E["teams"][opp_id]
    me, opp = players_of(me_rec["roster"]), players_of(op_rec["roster"])
    alerts = injury_alerts({t["id"]: t["roster"] for t in E["teams"].values()}, E["fa"], MY_TEAM, opp_id, now_utc.strftime("%Y-%m-%d %H:%M UTC"))
    if not pre and not espn:
        lagged = apply_espn_lag(E, mp, today, opp_id)
        if lagged:
            warnings.append("ESPN has not posted " + ", ".join(sorted({x[0] for x in lagged})) +
                            " to the matchup yet; totals use the public box scores for that day until it does")
    act_me = E["box"]["me"] if E.get("box") else None
    act_op = E["box"]["opp"] if E.get("box") else None
    # free agents (waiver-locked ones only count from their release date)
    fa_recs = []
    for f in E["fa"]:
        if f.get("waiver_date") and f["status"] == "WAIVERS":
            f = {**f, "avail_from": f["waiver_date"] if date.fromisoformat(f["waiver_date"]) > today else None}
        fa_recs.append(f)
    ok_fa = [r for r in fa_recs if proj.get(norm(r["name"])) or fallback_projection(r["name"])]
    fa_pl = players_of(fa_recs)
    for p, rec in zip(fa_pl, ok_fa):
        p["status"], p["own"], p["avail_from"] = rec["status"], rec.get("own"), rec.get("avail_from")
    # the opponent will stream too: model what they could do with the adds they have left, weighted by how often they actually add
    opp_pack = team_pack(opp, wk, act_op, BAL)
    opp_hist = E.get("adds_hist", {}).get(opp_id, {})
    opp_adds_left = max(0, wk.adds - opp_hist.get(mp, 0))
    s_prop = opp_propensity(opp_hist, mp)
    my_bal = team_pack(me, wk, act_me, BAL)
    opp_adj_pack, opp_moves = opp_pack, []
    if opp_adds_left > 0 and not wk.finished:
        adj_roster, opp_moves = opp_best_response(opp, my_bal, wk, act_op, fa_pl, opp_adds_left)
        if opp_moves:
            opp_adj_pack = team_pack(adj_roster, wk, act_op, BAL)
    ref_pack = opp_adj_pack if s_prop >= 0.5 else opp_pack         # my own lineup/streaming choices are made against the likelier opponent
    w, pk_me, _ = optimise_weights(me, ref_pack, wk, act_me, BAL)
    pc_s, pw_s, t_me, t_op = matchup_eval(pk_me, opp_pack)
    pc_a, pw_a, _, t_opa = matchup_eval(pk_me, opp_adj_pack)
    pw = (1 - s_prop) * pw_s + s_prop * pw_a                         # mixture of the two opponent scenarios
    pc = (1 - s_prop) * pc_s + s_prop * pc_a
    pw, pw_s, pw_a = calib_win(pw), calib_win(pw_s), calib_win(pw_a)   # shown / logged values (decisions below use the matchup_eval results)
    pc_r, pw_r, *_ = matchup_eval(pk_me, ref_pack)
    import inseason_track as TR
    TR.log_prediction(mp, today, now_utc.strftime("%Y-%m-%d %H:%M UTC"), op_rec["name"], pw, {c: pc[i] for i, c in enumerate(CATS)},
                      week_start=wk.start)
    TR.resolve_finished(E.get("lg"), mp, MY_TEAM)
    cur_me = cat_values(np.array([float((act_me or {}).get(ESPN_STAT[c], {}).get("value", 0.0)) for c in COMP]))
    cur_op = cat_values(np.array([float((act_op or {}).get(ESPN_STAT[c], {}).get("value", 0.0)) for c in COMP]))
    pm, po, poa = cat_values(t_me), cat_values(t_op), cat_values(t_opa)
    cats = []
    for i, c in enumerate(CATS):
        tag = "lock" if pc[i] >= 0.8 else ("lean" if pc[i] >= 0.6 else ("toss-up" if pc[i] > 0.4 else ("lean opp" if pc[i] > 0.2 else "concede")))
        cats.append({"key": c, "label": LABEL[c], "me_now": cur_me[c], "opp_now": cur_op[c], "me_proj": pm[c], "opp_proj": po[c],
                     "opp_proj_stream": poa[c], "p": float(pc[i]), "p_static": float(pc_s[i]), "p_stream": float(pc_a[i]), "tag": tag,
                     "weight": float(w[i] / BAL[i]), "lower_better": c in LOWER_BETTER})
    # daily path
    path = []                                    # cumulative expected standing after each day (means only: who is ahead in how many cats)
    for d in range(wk.today_idx, wk.n):
        _, _, a, b = matchup_eval(pk_me, opp_pack, upto=d)
        va, vb = cat_values(a), cat_values(b)
        lead = {c: (va[c] < vb[c]) if c in LOWER_BETTER else (va[c] > vb[c]) for c in CATS}
        path.append({"day": d, "label": (wk.start + timedelta(days=d)).strftime("%a %m/%d"), "leads": int(sum(lead.values())),
                     "lead_cats": [LABEL[c] for c in CATS if lead[c]]})
    # starts grid
    grid = {}
    for name, d, v, p in pk_me["plan"]["starts"]:
        grid.setdefault(name, {})[d] = round(p, 2)
    days = [(wk.start + timedelta(days=i)).strftime("%a %m/%d") for i in range(wk.n)]
    # streaming (against the likelier opponent scenario)
    adds_left = max(0, wk.adds - E.get("adds_used", 0))
    stream = streaming(me, ref_pack, wk, act_me, w, fa_pl, adds_left, pw_r, float(pc_r.sum()), pc_r, pm)
    from inseason_league import league_block
    league, _st = league_block(E, proj, today, mp, now_utc, MY_TEAM, opp_id)
    seen, top = set(), []
    for r in stream:
        if r["add"] in seen:
            continue
        seen.add(r["add"]); top.append(r)
        if len(top) >= 12:
            break

    def mixed(pk):
        """The whole category table as it would look with this roster: blend of the two opponent scenarios, matchup chance as displayed."""
        pcs, pws, t1, _ = matchup_eval(pk, opp_pack)
        pca, pwa, _, _ = matchup_eval(pk, opp_adj_pack)
        pcm = (1 - s_prop) * pcs + s_prop * pca
        vals = cat_values(t1)
        return {"p_win": calib_win((1 - s_prop) * pws + s_prop * pwa),
                "cats": {c: {"me_proj": float(vals[c]), "p": float(pcm[i])} for i, c in enumerate(CATS)}}

    fa_by = {f["name"]: f for f in fa_pl}
    for r in top[:6]:                                                # "Preview" data: the category table after each of the best swaps
        if r["add"] in fa_by:
            r["after"] = mixed(team_pack([q for q in me if q["name"] != r["drop"]] + [fa_by[r["add"]]], wk, act_me, w))
    # daily streaming tactics: 1 spot vs 2 spots under the real add limit
    import inseason_plan as IP
    sp = IP.plans(me, ref_pack, wk, act_me, w, fa_pl, adds_left, pw_r)
    scale = (calib_win(min(0.995, pw_r + 0.005)) - calib_win(max(0.005, pw_r - 0.005))) / 0.01     # raw win-chance gain -> displayed (calibrated) gain
    stream_plans = {"adds_left": adds_left, "limit": wk.adds, "base": {"p_win": pw}, "plans": [], "days": IP.day_map(sp, wk, scale) if sp else [],
                    "sunday": wk.sun, "single": IP.best_single(sp, wk, scale) if sp else None}
    sgl = stream_plans.get("single")
    if sgl:                                                          # the single add's gain on the SAME scale as the plans (the whole displayed table after the move)
        f_, t_, h_, cut_ = sgl.pop("_f"), sgl.pop("_t"), sgl.pop("_hold"), sgl.pop("_cut")
        aft = mixed(team_pack(IP._roster(me, cut_, [(f_, t_, h_)]), wk, act_me, w))
        sgl["gain"], sgl["after"] = aft["p_win"] - pw, aft
    def build_block(spx):
        """Turn a {K: plan} search result into the page's plan list (steps, gain, costs, what-if table) and the per-day step lists."""
        out_plans, sbk = [], {}
        for K in sorted(k for k in spx if isinstance(k, int)):
            res = spx[K]
            after = mixed(team_pack(IP._roster(me, res["cut"], [(f, t, h) for f, t, h in res["plan"]]), wk, act_me, w)) if res["plan"] else None
            raw_total = res["pw"] - res["pw_base"]
            sc = ((after["p_win"] - pw) / raw_total) if (after and raw_total > 1e-6) else scale     # so the per-add gains add up to the plan's displayed total
            steps = IP.describe(res, wk, sc)
            sbk[K] = steps
            costs = gains = []
            if after:                                                # what the plan gives up: categories whose win chance falls (extra players can hurt FG%, 3P%, TO, PF)
                base_p = {c["key"]: c["p"] for c in cats}
                dpc = [(c["label"], after["cats"][c["key"]]["p"] - base_p[c["key"]], c["key"]) for c in cats]
                costs = [{"cat": l, "dp": d, "was": base_p[k], "now": base_p[k] + d, "to_toss_up": base_p[k] >= 0.6 > base_p[k] + d}
                         for l, d, k in sorted(dpc, key=lambda x: x[1]) if d <= -0.03]
                gains = [{"cat": l, "dp": d} for l, d, k in sorted(dpc, key=lambda x: -x[1]) if d >= 0.03]
            out_plans.append({"K": K, "costs": costs, "gains": gains, "adds_used": res["adds_used"], "steps": steps, "donors": res["donors"],
                              "p_win": after["p_win"] if after else pw, "gain": (after["p_win"] - pw) if after else 0.0, "after": after,
                              "sunday_adds": sum(1 for s in steps if wk.sun is not None and s["day"] == wk.sun),
                              "b2b_holds": sum(1 for s in steps if s["b2b"])})
        return out_plans, sbk

    # ONE scoring rule for every "add this player" number on the page (Today single add, Streaming tab, FA tab): each free agent is scored
    # at his best start day and hold from the planner's first scan (replacing the plan's donor), shown on the displayed (mixed, calibrated) scale.
    # Free agents the planner has no timed option for fall back to a whole-week swap, scored the same way.
    res1 = next((v for k_, v in sp.items() if isinstance(k_, int)), None) if sp else None
    donor = res1["donors"][0] if res1 and res1["donors"] else None
    timed = {}
    for (nm_, t_, h_), g_ in (res1["first_gain"].items() if res1 else ()):
        if g_ > 0 and (nm_ not in timed or g_ > timed[nm_][2]):
            timed[nm_] = (t_, h_, g_)
    base_cp = {c["key"]: (c["p"], c["me_proj"]) for c in cats}
    firsts = {}
    for r in stream:
        firsts.setdefault(r["add"], r)
    rescored = []
    for nm_, r in firsts.items():
        f_ = fa_by.get(nm_)
        if f_ is None:
            continue
        t_ = h_ = None
        if donor and nm_ in timed:
            t_, h_, _g = timed[nm_]
            roster_ = IP._roster(me, {donor: t_ - 1}, [(f_, t_, h_)])
            drop_ = donor
        else:
            roster_ = [q for q in me if q["name"] != r["drop"]] + [f_]
            drop_ = r["drop"]
        aft = mixed(team_pack(roster_, wk, act_me, w))
        eff = [{"cat": LABEL[c], "dp": aft["cats"][c]["p"] - base_cp[c][0], "dproj": aft["cats"][c]["me_proj"] - base_cp[c][1],
                "lower_better": c in LOWER_BETTER} for c in CATS]
        pdays_ = wk.play_days().get(f_["team"], ())
        r2 = dict(r, drop=drop_, d_pwin=aft["p_win"] - pw, d_cats=sum(e["dp"] for e in eff), after=aft,
                  helps=sorted([e for e in eff if e["dp"] >= 0.01], key=lambda e: -e["dp"]),
                  hurts=sorted([e for e in eff if e["dp"] <= -0.01], key=lambda e: e["dp"]),
                  when=(wk.start + timedelta(days=t_)).strftime("%a %m/%d") if t_ is not None else None, hold=h_,
                  games_in_hold=[(wk.start + timedelta(days=d)).strftime("%a") for d in range((t_ if t_ is not None else 0), (t_ + h_) if t_ is not None else wk.n)
                                 if d in pdays_] if t_ is not None else None)
        rescored.append(r2)
    rescored.sort(key=lambda x: -(x["d_pwin"] + 0.02 * x["d_cats"]))
    stream = rescored or stream
    top = stream[:12]
    for r in stream[12:]:
        r.pop("after", None)
    best_t = next((r for r in stream if r.get("when")), None)
    if best_t:                                                     # the Today card's "only one add" is the top timed row of the same list
        f_ = fa_by[best_t["add"]]
        sgl = {"add": best_t["add"], "team": best_t["add_team"], "start": best_t["when"], "day": timed[best_t["add"]][0], "hold": best_t["hold"],
               "games": best_t["games_in_hold"], "gain": best_t["d_pwin"], "donor": best_t["drop"], "after": best_t["after"]}
        stream_plans["single"] = sgl
    stream_plans["plans"], steps_by_k = build_block(sp)
    steps_by_p = {}
    if sp:                                                           # 'protect' variant: same search, but TO / FG% / 3P% / PF leads may not slip
        guard = IP.make_guard(me, ref_pack, wk, act_me, w)
        if guard["items"]:
            spp = IP.plans(me, ref_pack, wk, act_me, w, fa_pl, adds_left, pw_r, guard=guard["items"])
            plans_p, steps_by_p = build_block(spp)
            stream_plans["protect"] = {"cats": guard["labels"], "floors": guard["floors"], "plans": plans_p, "rule":
                                       f"{', '.join(guard['labels'])}: each is a lead you hold at {int(IP.PROTECT_MIN * 100)}%+ now; a plan may not push it below "
                                       f"{int(IP.PROTECT_FLOOR * 100)}% or lose more than {int(IP.PROTECT_MAX_DROP * 100)} points."}
    global _ODDS
    _REAL_TODAY[0] = wk.real_today
    try:                                                             # Vegas lines are display-only (blowout flag for near days; later days are early lines)
        import inseason_odds as IOD
        _ODDS = IOD.refresh([wk.start + timedelta(days=i) for i in range(wk.today_idx, wk.n)], wk.real_today) or IOD.load()
    except Exception:
        _ODDS = {}
    lineups = _lineups(pk_me, wk, E, me_rec, MY_TEAM, steps_by_k, steps_by_p)
    fa_list = {"rows": [], "near": [], "thresholds": {}, "mine": [], "n_pool": 0}
    try:                                                             # free-agent list: MUST / STREAM / WATCH from projection, box scores and fit
        import inseason_fa as IFA
        plan_names = {s["add"] for p_ in stream_plans["plans"] for s in p_["steps"]}
        fa_list = IFA.build_fa(me, fa_pl, wk, stream, plan_names, league, today, adds_left)
    except Exception as ex:
        import traceback
        traceback.print_exc()
        warnings.append(f"free-agent list unavailable ({type(ex).__name__}: {str(ex)[:80]})")
    rater, rosters = None, None
    try:                                                             # ESPN player rater vs ours, and per-team roster analysis
        import inseason_rater as IRT
        rater, rosters = IRT.build(E, proj)
    except Exception as ex:
        import traceback
        traceback.print_exc()
        warnings.append(f"player rater unavailable ({type(ex).__name__}: {str(ex)[:80]})")
    trades = {"rows": []}
    try:                                                             # trade finder: win-win deals found with the same engine
        import time as _t
        import inseason_trade as ITR
        _t0 = _t.time()
        trades = ITR.find_trades(E, proj, today, mp, MY_TEAM, league, fa_pl)
        trades["seconds"] = round(_t.time() - _t0, 1)
        try:
            trades["by_partner"] = ITR.partner_trades(E, proj, today, mp, MY_TEAM, league, fa_pl)
        except Exception as ex2:
            import traceback
            traceback.print_exc()
            warnings.append(f"partner trades unavailable ({type(ex2).__name__}: {str(ex2)[:80]})")
    except Exception as ex:
        import traceback
        traceback.print_exc()
        warnings.append(f"trade finder unavailable ({type(ex).__name__}: {str(ex)[:80]})")
    sun_state = "n/a" if wk.sun is None else ("locked (over the cap)" if pk_me["gp"] > wk.cap else "open")
    notes = []
    if wk.assumed and HAS_CAP:
        notes.append("Week 18 is the two-week All-Star matchup: cap and add limit are ASSUMED (2 x 33, 7 adds) until you confirm them.")
    elif wk.assumed:
        notes.append(f"This is a two-week matchup: the add limit is ASSUMED to double ({wk.adds} adds) until you confirm it on ESPN.")
    if pre:
        notes.append("Season has not started: this is a preview of week 1 (Tue Oct 20 - Sun Oct 25) with preseason projections.")
    if not E.get("box"):
        notes.append("ESPN matchup totals were unavailable; showing projections only.")
    state = {
        "cfg": {"key": LC.KEY, "title": LC.C["title"], "name": LC.C["name"], "n_teams": N_TEAMS, "has_cap": HAS_CAP, "n_slots": len(A.SLOTS),
                "slots": list(A.SLOTS), "repo": LC.C["repo"], "site": LC.C["site"], "trade_deadline": LC.C["trade_deadline"],
                "playoff_teams": LC.C["playoff_teams"], "league_id": LEAGUE_ID, "private": LC.C["private"]},
        "asof": now_utc.strftime("%Y-%m-%d %H:%M UTC"), "preseason": pre,
        "week": {"mp": mp, "start": wk.start.isoformat(), "end": wk.end.isoformat(), "days": days, "today_idx": wk.today_idx,
                 "cap": wk.cap, "gp_me": pk_me["gp"], "gp_opp": opp_pack["gp"], "adds_limit": wk.adds, "adds_used": E.get("adds_used", 0),
                 "adds_left": adds_left, "sunday": sun_state, "plan_mode": pk_me["plan"]["mode"],
                 "exp_cap_use": round(pk_me["plan"]["exp_cap_use"], 1)},
        "me": {"name": me_rec["name"], "owner": me_rec["owner"]}, "opp": {"name": op_rec["name"], "owner": op_rec["owner"]},
        "p_win": pw, "p_win_static": pw_s, "p_win_stream": pw_a, "exp_cats": float(pc.sum()), "cats": cats, "path": path,
        "opp_watch": {"propensity": s_prop, "adds_used": opp_hist.get(mp, 0), "adds_left": opp_adds_left, "limit": wk.adds, "moves": opp_moves,
                      "history": {str(k): v for k, v in sorted(opp_hist.items())}, "ref": "streamed" if s_prop >= 0.5 else "as-is"},
        "league": league,
        "need_cats": [c["key"] for c in cats if c["p"] < 0.5],
        "grid": [{"name": n, "team": pk_me["by"][n]["team"], "inj": pk_me["by"][n]["inj"], "days": {str(k): v for k, v in dd.items()}}
                 for n, dd in sorted(grid.items(), key=lambda kv: -sum(kv[1].values()))],
        "lineups": lineups, "streaming": top, "stream_plans": stream_plans, "adds_left_note": f"{adds_left} of {wk.adds} adds left this week",
        "roster": [{"name": p["name"], "team": p["team"], "elig": sorted(p["elig"]), "inj": p["inj"], "p": p["p"], "src": p["src"],
                    "games_left": wk.games_left(p["team"]), "ret": str(p["ret"]) if p.get("ret") else None,
                    "note": (p.get("news") or {}).get("comment")} for p in me],
        "alerts": alerts, "track": TR.summary(),
        "opp_roster": [{"name": p["name"], "team": p["team"], "inj": p["inj"]} for p in opp],
        "warnings": warnings[:20], "notes": notes, "fa": fa_list, "trades": trades, "rater": rater, "rosters": rosters,
    }
    from inseason_actions import build_actions
    state["actions"] = build_actions(state)
    return state


def _opp_from_schedule(E, mp):
    lg = LC.open_league()
    m = lg.teams[0].schedule[mp - 1]
    for t in (m.home_team, m.away_team):
        if t.team_id != MY_TEAM:
            return t.team_id


def _boost_text(team, name, day_date, real_today):
    m, who = absence_m(team, norm(name), day_date, real_today)
    if m > 0.04:
        return f"{', '.join(n for n, _ in who[:2])} out: about +{ABS_K[0] * m * 100:.0f}% points and usage"
    return None


_ODDS = {}
_REAL_TODAY = [None]


def _line(team, day):
    try:
        import inseason_odds as IOD
        return IOD.note(_ODDS, day, team, _REAL_TODAY[0])
    except Exception:
        return None


def _lineups(pk, wk, E, me_rec, tid, steps_by_k=None, steps_by_p=None):
    """Recommended lineup for EVERY remaining day of the matchup. Only the first day can be compared with what is set on ESPN
    (ESPN shows the current scoring period's lineup); later days are the plan if nothing changes (injuries, news, adds)."""
    starts = pk["plan"]["starts"]
    cur = E.get("lineup", {}).get(tid, {})
    cur_by_name = {r["name"]: cur.get(r["id"]) for r in me_rec["roster"]}
    order = {"PG": 0, "SG": 1, "SF": 2, "PF": 3, "C": 4, "G": 5, "F": 6, "UTIL1": 7, "UTIL2": 8, "UTIL3": 9, "UTIL": 7}
    out, cum, first = [], pk["gp"], True
    for day in range(wk.today_idx, wk.n):
        g = wk.sch[wk.sch["idx"] == day]
        if day == wk.today_idx:
            g = g[~g["started"]]
        opp_of = {r.team: (r.opp, r.home) for r in g.itertuples()}
        tip_of = {r.team: pd.Timestamp(r.tip_utc).strftime("%Y-%m-%dT%H:%M:00Z") for r in g.itertuples()}
        mine_playing = {n: opp_of[v["team"]] for n, v in pk["by"].items() if v["team"] in opp_of and v.get("avail_ok", True)}
        if not mine_playing:
            continue
        sel = [s for s in starts if s[1] == day]
        names = [s[0] for s in sel]
        p_day = {s[0]: s[3] for s in sel}
        sl = A.assign_slots({n: pk["by"][n]["elig"] for n in names}) or {}
        slot_of = {v: k for k, v in sl.items()}
        starters = [{"slot": re.sub(r"UTIL\d", "UTIL", slot_of.get(n, "-")), "name": n, "team": pk["by"][n]["team"],
                     "opp": ("vs " if mine_playing[n][1] else "@ ") + mine_playing[n][0], "p": p_day[n], "inj": pk["by"][n]["inj"],
                     "tip": tip_of.get(pk["by"][n]["team"]), "_o": order.get(slot_of.get(n, "-"), 9),
                     "boost": _boost_text(pk["by"][n]["team"], n, wk.start + timedelta(days=day), wk.real_today),
                     "line": _line(pk["by"][n]["team"], wk.start + timedelta(days=day))} for n in names]
        starters.sort(key=lambda s: s["_o"])
        for s in starters:
            s.pop("_o")
        sits = []
        for n, o in mine_playing.items():
            if n in names:
                continue
            if pk["by"][n]["inj"] and str(pk["by"][n]["inj"]).upper() in ("OUT", "SUSPENSION", "INJURY_RESERVE"):
                why = "out"
            elif len(names) >= len(A.SLOTS):
                why = f"all {len(A.SLOTS)} slots filled by better options"
            else:
                why = "would hurt more than he helps in the categories you are chasing"
            sits.append({"name": n, "team": pk["by"][n]["team"], "opp": ("vs " if o[1] else "@ ") + o[0], "why": why,
                         "tip": tip_of.get(pk["by"][n]["team"])})
        is_sun = wk.sun is not None and day == wk.sun
        if not is_sun:
            cum += sum(p_day.values())
        changes = []
        if first and cur:
            for n in names:
                if cur_by_name.get(n) in (None, "BE", "IR"):
                    changes.append({"move": "START", "name": n})
            for n, s in cur_by_name.items():
                if s not in (None, "BE", "IR") and n not in names and n in mine_playing:
                    changes.append({"move": "BENCH", "name": n})
        stream = {}
        for pre, src in (("k", steps_by_k), ("p", steps_by_p)):      # the daily-streaming tactic for this day (add today / keep from yesterday); k = max win chance, p = protect
            for K, steps in (src or {}).items():
                stream[f"{pre}{K}"] = [{"add": s["add"], "team": s["team"], "new": s["day"] == day, "drops": s["drops"], "boost": s["boost"], "spot": s["spot"]}
                                       for s in steps if s["day"] <= day < s["day"] + s["hold"]]
        out.append({"day": day, "label": (wk.start + timedelta(days=day)).strftime("%a %m/%d"), "sunday": is_sun, "start": starters, "sits": sits,
                    "stream": stream,
                    "n_start": len(names), "exp_starts_counted": round(sum(p_day.values()), 1), "exp_cum": round(cum, 1),
                    "changes": changes, "vs_espn": first and bool(cur)})
        first = False
    return out


if __name__ == "__main__":
    import time
    t0 = time.time()
    s = build_state()
    print(f"built in {time.time() - t0:.1f}s | week {s['week']['mp']} {s['week']['start']}..{s['week']['end']} | {s['me']['name']} vs {s['opp']['name']}")
    print(f"P(win) = {s['p_win']:.1%} | expected cats {s['exp_cats']:.2f} | plan {s['week']['plan_mode']} | adds left {s['week']['adds_left']}")
    for c in s["cats"]:
        print(f"  {c['label']:5s} me {c['me_proj']:8.2f} opp {c['opp_proj']:8.2f}  P={c['p']:.2f} {c['tag']:9s} w x{c['weight']:.1f}")
    print("path (cats I lead, cumulative):", [(p['label'], p['leads']) for p in s["path"]])
    for ln in s["lineups"]:
        print("lineup", ln["label"], f"({ln['n_start']} starts, cum exp {ln['exp_cum']})", [x["name"].split()[-1] + "@" + x["slot"] for x in ln["start"]],
              "| sits:", [x["name"].split()[-1] for x in ln["sits"]], ln["changes"])
    for r in s["streaming"][:8]:
        print(f"  +{r['add']} ({r['add_team']}, {r['games_left']}g, {r['add_status']}, {r['add_wait']}) -{r['drop']}  dP={r['d_pwin']:+.1%} dCats={r['d_cats']:+.2f}  helps: "
              + ", ".join(f"{e['cat']} {e['dp']:+.0%}" for e in r["helps"][:4]) + " | hurts: " + ", ".join(f"{e['cat']} {e['dp']:+.0%}" for e in r["hurts"][:4]))
    print("warnings:", s["warnings"][:5]); print("notes:", s["notes"])
    json.dump(s, open(ROOT / "data" / ("live_state.json" if LC.KEY == "lapis" else f"live_state_{LC.KEY}.json"), "w"), default=float)
