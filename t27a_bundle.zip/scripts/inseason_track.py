"""Track record: does the app's win chance mean what it says?

Every refresh logs the current matchup's prediction (win chance and each category's chance). Once a matchup period is over, the real
result is read from ESPN's box score (category-by-category win / loss / tie) and scored:
  Brier = mean squared gap between the chance given and what happened (0 = perfect, 0.25 = a coin flip's score, lower is better)
  hit   = the side the app favoured at the start of the week actually won
The first prediction of the week (before games) is the one scored, because that is the one you would act on; the last one is kept too.
Stored in data/live/predictions.json.
"""
import json
from pathlib import Path

import league_cfg as LC

ROOT = Path(__file__).resolve().parent.parent
F = LC.LIVE / "predictions.json"
ESPN_CAT = {"PTS": "pts", "STL": "stl", "BLK": "blk", "OREB": "oreb", "DREB": "dreb", "FG%": "fg_pct", "3PM": "3pm", "3PT%": "3p_pct", "3P%": "3p_pct",
            "FTM": "ftm", "FT%": "ft_pct", "TO": "to", "PF": "pf", "AST": "ast"}


def _load():
    try:
        return json.loads(F.read_text(encoding="utf-8-sig"))
    except Exception:
        return {"log": {}, "results": {}}


def _save(d):
    F.parent.mkdir(parents=True, exist_ok=True)
    F.write_text(json.dumps(d), encoding="utf-8")


def log_prediction(mp, day, ts, opp, p_win, p_cat, week_start=None):
    """`first` = the prediction at the start of the matchup: previews made before `week_start` keep overwriting it, the first one made
    on or after that day freezes it (that is the one scored later)."""
    d = _load()
    e = d["log"].setdefault(str(mp), {"opp": opp, "first": None, "last": None})
    rec = {"ts": ts, "day": str(day), "p_win": float(p_win), "p_cat": {k: float(v) for k, v in p_cat.items()}}
    if e["first"] is None or (week_start is not None and str(e["first"]["day"]) < str(week_start)):
        e["first"] = rec
    e["last"], e["opp"] = rec, opp
    _save(d)


def resolve_finished(lg, mp, my_id):
    """Read the final category results of every matchup period before `mp` that has not been recorded yet."""
    if lg is None:
        return
    d = _load()
    changed = False
    for p in range(1, mp):
        if str(p) in d["results"] or str(p) not in d["log"]:
            continue
        try:
            for b in lg.box_scores(matchup_period=p, matchup_total=True):
                mine_home = b.home_team.team_id == my_id
                if not mine_home and getattr(b.away_team, "team_id", None) != my_id:
                    continue
                mine, theirs = (b.home_stats, b.away_stats) if mine_home else (b.away_stats, b.home_stats)
                res = {}
                for k, v in mine.items():
                    if k in ESPN_CAT and v.get("result") in ("WIN", "LOSS", "TIE"):
                        res[ESPN_CAT[k]] = {"WIN": 1.0, "TIE": 0.5, "LOSS": 0.0}[v["result"]]
                w, l, t = (b.home_wins, b.home_losses, b.home_ties) if mine_home else (b.away_wins, b.away_losses, b.away_ties)
                if len(res) >= 13 and (w + l + t) >= 13:
                    d["results"][str(p)] = {"cats": res, "w": w, "l": l, "t": t, "won": 1.0 if w > l else (0.5 if w == l else 0.0)}
                    changed = True
        except Exception as e:
            print("track: could not resolve period", p, type(e).__name__)
    if changed:
        _save(d)


def summary():
    d = _load()
    rows, bw, bc, hits = [], [], [], 0
    for p, r in sorted(d["results"].items(), key=lambda kv: int(kv[0])):
        e = d["log"].get(p)
        if not e or not e.get("first"):
            continue
        f = e["first"]
        bwk = (f["p_win"] - r["won"]) ** 2
        cats = [(f["p_cat"][c] - y) ** 2 for c, y in r["cats"].items() if c in f["p_cat"]]
        bck = sum(cats) / len(cats) if cats else None
        hit = (f["p_win"] > 0.5) == (r["won"] > 0.5)
        bw.append(bwk); hits += hit
        if bck is not None:
            bc.append(bck)
        rows.append({"mp": int(p), "opp": e["opp"], "p_win_first": f["p_win"], "p_win_last": e["last"]["p_win"], "cats": f"{r['w']}-{r['l']}-{r['t']}",
                     "won": r["won"], "brier": bwk, "hit": bool(hit)})
    n = len(rows)
    return {"n": n, "brier_win": (sum(bw) / n) if n else None, "brier_cat": (sum(bc) / len(bc)) if bc else None, "naive": 0.25,
            "hit_rate": (hits / n) if n else None, "weeks": rows[-8:]}
