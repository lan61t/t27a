"""G-score and a roster-aware dynamic drafter ("H-style") for a 13-category, head-to-head MOST-categories league.

Static (Rosenof 2024a):  G_c = ratio_c * z_c   (ratio from real weekly data, see gscore.py)
Dynamic (in the spirit of Rosenof 2024b, "H-scoring"): at every pick, for each candidate player and for each
category-emphasis vector j (balanced, soft-punt one category, hard-punt one category, hard-punt a curated pair),
simulate the REST of my draft (I keep taking the best remaining player under j; opponents take what the room
values), then score the finished roster by its probability of winning a weekly matchup (>= 7 of 13 categories
vs an average opponent, categories independent, normal approximation with weekly noise from real data).
Pick the candidate whose best j gives the highest win probability. Punting therefore emerges from the roster,
the way the paper's algorithm learns it.

Everything works in the 'Q-based z' scale of percat.py.
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
CATS13 = ["pts", "stl", "blk", "oreb", "dreb", "fg_pct", "3pm", "3p_pct", "ftm", "ft_pct", "to", "pf", "ast"]
CI = {c: i for i, c in enumerate(CATS13)}
KAPPA = 24 / 23
N_TEAMS, N_ROUNDS, N_START = 14, 12, 7
BENCH_W = 0.35
_R = pd.read_csv(ROOT / "data" / "research" / "g_ratios.csv", index_col=0).loc[CATS13]
RATIO = _R["mean"].to_numpy()                       # G/Z reliability per category
TAU = np.sqrt((1 / RATIO ** 2 - 1) / KAPPA)         # weekly noise per player, in z units


def cdf(x):
    z = np.asarray(x, dtype=float) / np.sqrt(2.0)
    a = np.abs(z)
    t = 1.0 / (1.0 + 0.3275911 * a)
    poly = t * (0.254829592 + t * (-0.284496736 + t * (1.421413741 + t * (-1.453152027 + t * 1.061405429))))
    return 0.5 * (1.0 + np.sign(z) * (1.0 - poly * np.exp(-a * a)))


def snake(n_teams=N_TEAMS, n_rounds=N_ROUNDS):
    out = []
    for r in range(n_rounds):
        out += (list(range(n_teams)) if r % 2 == 0 else list(range(n_teams - 1, -1, -1)))
    return out


SEQ = snake()


def avail_scale(v, gp, lam=1.0):
    f = (np.clip(gp, 0.35, 0.98) / 0.80) ** lam
    return np.where(v > 0, v * f, v)


def win_prob_matrix(S, mu, s, noise_extra=0.0):
    """S: (m, 13) team strengths -> (m,) P(win >= 7 categories) vs an average opponent."""
    sig = np.sqrt(s ** 2 + 2 * N_START * TAU ** 2 + noise_extra)
    p = cdf((S - mu) / sig)
    dp = np.zeros((S.shape[0], 14)); dp[:, 0] = 1.0
    for c in range(13):
        nxt = dp * (1 - p[:, [c]])
        nxt[:, 1:] += dp[:, :-1] * p[:, [c]]
        dp = nxt
    return dp[:, 7:].sum(axis=1)


def cat_win_probs(S, mu, s):
    sig = np.sqrt(s ** 2 + 2 * N_START * TAU ** 2)
    return cdf((S - mu) / sig)


def roster_strength(ids, Zp, gp):
    """Expected category strength: top-7 by balanced G weight 1, others BENCH_W, each x games share."""
    ids = np.asarray(ids)
    g = (Zp[ids] * RATIO).sum(axis=1)
    order = np.argsort(-g)
    w = np.where(np.arange(len(ids)) < N_START, 1.0, BENCH_W)
    S = (Zp[ids][order] * (w * gp[ids][order])[:, None]).sum(axis=0)
    return S


# curated emphasis vectors: balanced; soft (x0.5) and hard (x0) punt of each single category; hard pairs among the noisy cats
def build_J():
    J, names = [np.ones(13)], ["balanced"]
    for c in CATS13:
        v = np.ones(13); v[CI[c]] = 0.5; J.append(v); names.append(f"soft:{c}")
    for c in CATS13:
        v = np.ones(13); v[CI[c]] = 0.0; J.append(v); names.append(f"punt:{c}")
    pairs = [("3p_pct", "stl"), ("3p_pct", "pf"), ("3p_pct", "to"), ("to", "pf"), ("stl", "pf"), ("ft_pct", "fg_pct"),
             ("ft_pct", "ftm"), ("ast", "to")]
    for a, b in pairs:
        v = np.ones(13); v[CI[a]] = 0.0; v[CI[b]] = 0.0
        J.append(v); names.append(f"punt:{a}+{b}")
    return np.array(J), names


J_ALL, J_NAMES = build_J()


def opp_baseline(room_score, Zp, gp, rng, n_drafts=8, noise_sd=0.8, shared_sd=0.0):
    """Mean / spread (across teams) of room-drafted team strengths, used as 'an average opponent'."""
    n = len(room_score)
    Ss = []
    for _ in range(n_drafts):
        base = room_score + rng.normal(0, shared_sd, n) if shared_sd else room_score
        pn = [rng.normal(0, noise_sd, n) for _ in range(N_TEAMS)]
        taken = np.zeros(n, dtype=bool)
        ros = [[] for _ in range(N_TEAMS)]
        for t in SEQ:
            s = np.where(taken, -np.inf, base + pn[t])
            i = int(np.argmax(s)); taken[i] = True; ros[t].append(i)
        Ss.append(np.array([roster_strength(r, Zp, gp) for r in ros]))
    A = np.concatenate(Ss)
    return A.mean(axis=0), A.std(axis=0)


class Drafter:
    """One simulated draft from my seat. Room scores drive every opponent; I use `policy`."""

    def __init__(self, Zp, gp, room_score, mu_opp, s_opp, elig=None, need_slots=None):
        self.Zp, self.gp, self.room = Zp, gp, room_score
        self.mu, self.s = mu_opp, s_opp
        self.n = len(room_score)
        self.G = avail_scale((Zp * RATIO).sum(axis=1), gp)          # static G with availability
        self.elig, self.need0 = elig, need_slots

    # ---------------------------------------------------------- dynamic pick
    def h_pick(self, taken, mine, my_idx_in_seq, K=8, J=None, J_names=None, room_order=None, pos_state=None):
        Zp, gp = self.Zp, self.gp
        Jm = J_ALL if J is None else J
        avail_idx = np.where(~taken)[0]
        if pos_state is not None:
            ok = self._pos_ok(avail_idx, pos_state, len(mine))
            avail_idx = avail_idx[ok]
        # candidate pool: best K by balanced G plus best few under each single hard punt
        cands = set(avail_idx[np.argsort(-self.G[avail_idx])[:K]].tolist())
        for c in range(13):
            sc = avail_scale((Zp[avail_idx] * (RATIO * np.where(np.arange(13) == c, 0.0, 1.0))).sum(axis=1), gp[avail_idx])
            cands.update(avail_idx[np.argsort(-sc)[:1]].tolist())
        cands = np.array(sorted(cands))
        orders = []
        for jv in Jm:
            sc = avail_scale((Zp * (RATIO * jv)).sum(axis=1), gp)
            orders.append(np.argsort(-sc))
        seq_after = SEQ[my_idx_in_seq + 1:]
        best = (-1.0, None, None)
        results = np.zeros((len(cands), len(Jm)))
        for ci, p in enumerate(cands):
            for ji in range(len(Jm)):
                results[ci, ji] = self._rollout_value(taken, mine, p, seq_after, orders[ji], room_order, pos_state)
        ci, ji = np.unravel_index(np.argmax(results), results.shape)
        bestv, bestj = results.max(axis=1), results.argmax(axis=1)
        order = np.argsort(-bestv)
        ranked = [(int(cands[k]), float(bestv[k]), int(bestj[k])) for k in order[:10]]
        return int(cands[ci]), int(ji), float(results[ci, ji]), ranked

    def _pos_ok(self, idx, pos_state, k):
        """Hard feasibility: every required position still fillable with the picks left."""
        need = pos_state["open"]                       # array len 5 of open positional starters
        left = N_ROUNDS - k                            # picks remaining including this one
        open_n = int(need.sum())
        if left > open_n:
            return np.ones(len(idx), dtype=bool)
        # must fill an open position with this pick
        return (self.elig[idx][:, need > 0]).any(axis=1)

    def _rollout_value(self, taken0, mine, p, seq_after, order_j, room_order, pos_state):
        taken = taken0.copy()
        taken[p] = True
        ros = list(mine) + [p]
        pj = 0; pr = 0
        n = self.n
        for team in seq_after:
            if team == self._me:
                while taken[order_j[pj]]:
                    pj += 1
                i = order_j[pj]; ros.append(i)
            else:
                while taken[room_order[pr]]:
                    pr += 1
                i = room_order[pr]
            taken[i] = True
        S = roster_strength(ros, self.Zp, self.gp)
        return float(win_prob_matrix(S[None, :], self.mu, self.s)[0])

    # ---------------------------------------------------------- whole draft
    def run(self, my_slot, policy, rng, noise_sd=0.8, shared_sd=0.0, record=None, log_static=False):
        n = self.n
        self._me = my_slot
        base = self.room + (rng.normal(0, shared_sd, n) if shared_sd else 0.0)
        pn = [rng.normal(0, noise_sd, n) for _ in range(N_TEAMS)]
        taken = np.zeros(n, dtype=bool)
        ros = [[] for _ in range(N_TEAMS)]
        room_order = np.argsort(-base)
        pos_state = None
        if self.elig is not None:
            pos_state = {"open": np.ones(5)}
        build_log = []
        for k, t in enumerate(SEQ):
            if t == my_slot:
                if isinstance(policy, str) and policy == "room":
                    sc = np.where(taken, -np.inf, base + pn[t])
                    if pos_state is not None:
                        ok = self._pos_ok(np.arange(n), pos_state, len(ros[t]))
                        sc = np.where(ok, sc, -np.inf)
                    i = int(np.argmax(sc))
                elif policy == "h":
                    i, ji, val, ranked = self.h_pick(taken, ros[t], k, room_order=room_order, pos_state=pos_state)
                    build_log.append((J_NAMES[ji], val, ranked, taken.copy()))
                else:
                    sc = np.where(taken, -np.inf, policy(self, ros[t]))
                    if pos_state is not None:
                        ok = self._pos_ok(np.arange(n), pos_state, len(ros[t]))
                        sc = np.where(ok, sc, -np.inf)
                    i = int(np.argmax(sc))
                    if log_static:
                        top = np.argsort(-sc)[:8]
                        build_log.append(("static", float(sc[i]), [(int(j), float(sc[j]), 0) for j in top if np.isfinite(sc[j])], taken.copy()))
                if pos_state is not None:
                    e = self.elig[i] & (pos_state["open"] > 0)
                    if e.any():
                        pos_state["open"][int(np.argmax(e))] -= 1
            else:
                s = np.where(taken, -np.inf, base + pn[t])
                i = int(np.argmax(s))
            taken[i] = True
            ros[t].append(i)
        return ros, build_log
