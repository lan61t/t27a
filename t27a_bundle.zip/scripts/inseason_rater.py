"""Player rater and roster analysis for the Lapis league.

ESPN supplies only a RANK; every category number on the page is ours (the engine's per-game projection as 13 category ratings, 0 = average
draftable player, TO/PF negative when high).

ESPN rank, always the most current available:
  * once 2026-27 games are played (>= CUR_MIN_PLAYERS players with a game), ESPN's own Player Rater for the current season (view mStatRatings,
    statCategoryRanking). ESPN serves last season's rater until then, so that is NOT used before the season starts;
  * before that, ESPN's own 2026-27 PROJECTED season totals (stats id 102027) rated with ESPN's method: per-category z-score of the season total
    over the rated players (percentage categories by impact = made - pool% x attempts), TO/PF reversed, summed. Checked against ESPN's real
    2025-26 rater on 2025-26 actual totals: r = 0.999, mean error 0.6 rating points (the method, not the projections, is what is verified).
Rank diff = ESPN rank - our rank (positive = we rank him higher). Ours is ranked among the players we can project, ESPN among the players it
rates, so for deep-bench players the two sets differ a little.
"""
import json
import sys
from pathlib import Path

import numpy as np
from espn_api.basketball.constant import PRO_TEAM_MAP

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_fa as FA  # noqa: E402
import inseason_live as L  # noqa: E402

SID = {0: "pts", 1: "blk", 2: "stl", 3: "ast", 4: "oreb", 5: "dreb", 9: "pf", 11: "to", 15: "ftm", 17: "3pm", 19: "fg_pct", 20: "ft_pct", 21: "3p_pct"}
CNT = {"pts": 0, "blk": 1, "stl": 2, "ast": 3, "oreb": 4, "dreb": 5, "pf": 9, "to": 11, "ftm": 15, "3pm": 17}
PCTS = {"fg_pct": (13, 14), "ft_pct": (15, 16), "3p_pct": (17, 18)}
LIMIT = 700
CUR_SEASON, PROJ = "002027", "102027"
CUR_MIN_PLAYERS = 100


def fetch_ratings(lg):
    filt = {"players": {"filterStatus": {"value": ["FREEAGENT", "WAIVERS", "ONTEAM"]}, "filterSlotIds": {"value": list(range(0, 15))},
                        "limit": LIMIT, "sortPercOwned": {"sortPriority": 1, "sortAsc": False}}}
    d = lg.espn_request.league_get(params={"view": ["kona_player_info", "mStatRatings"]}, headers={"x-fantasy-filter": json.dumps(filt)})
    return d["players"]


def _totals(x, sid):
    for s in x["player"].get("stats", []):
        if s["id"] == sid and s.get("stats"):
            return {int(k): v for k, v in s["stats"].items()}
    return None


def espn_rate(raw, sid, min_gp=1):
    """ESPN-style rater on the season totals with id `sid`: {player id: total rating}. Pool = every player with those totals."""
    rows = [(x["id"], t) for x in raw for t in [_totals(x, sid)] if t and (t.get(42) or 0) >= min_gp]
    if len(rows) < 30:
        return {}
    z = np.zeros((len(rows), 13))
    for j, c in enumerate(L.CATS):
        if c in PCTS:
            m, a = PCTS[c]
            made = np.array([t.get(m, 0) for _, t in rows], dtype=float)
            att = np.array([t.get(a, 0) for _, t in rows], dtype=float)
            v = made - made.sum() / max(att.sum(), 1.0) * att
        else:
            v = np.array([t.get(CNT[c], 0) for _, t in rows], dtype=float)
        zz = (v - v.mean()) / (v.std() or 1.0)
        z[:, j] = -zz if c in L.LOWER_BETTER else zz
    tot = z.sum(axis=1)
    return {pid: float(tot[i]) for i, (pid, _) in enumerate(rows)}


def _pg(r):
    """Per-game projection in the league's 13 categories (same keys as L.CATS)."""
    g = lambda c: float(r[L.CI[c]])
    return {"pts": g("pts"), "stl": g("stl"), "blk": g("blk"), "oreb": g("oreb"), "dreb": g("dreb"), "fg_pct": g("fgm") / max(g("fga"), 1e-9),
            "3pm": g("3pm"), "3p_pct": g("3pm") / max(g("3pa"), 1e-9), "ftm": g("ftm"), "ft_pct": g("ftm") / max(g("fta"), 1e-9),
            "to": g("to"), "pf": g("pf"), "ast": g("ast")}


def _espn_ranks(raw):
    """({player id: ESPN rank}, mode, label). Current-season ESPN rater once games exist, else ESPN's 2026-27 projection rated by ESPN's method."""
    cur = espn_rate(raw, CUR_SEASON, 1)
    if len(cur) >= CUR_MIN_PLAYERS:
        rk = {x["id"]: int(x["ratings"]["0"]["statCategoryRanking"]) for x in raw
              if (x.get("ratings") or {}).get("0") and x["id"] in cur and x["ratings"]["0"].get("statCategoryRanking")}
        if rk:
            return rk, "current", "ESPN Player Rater, 2026-27 season so far"
    proj = espn_rate(raw, PROJ, 1)
    order = sorted(proj, key=lambda i: -proj[i])
    return {pid: k + 1 for k, pid in enumerate(order)}, "projection", "ESPN's 2026-27 projection (their projected season totals, rated with ESPN's method)"


def build(E, proj):
    raw = fetch_ratings(E["lg"])
    ranks, mode, label = _espn_ranks(raw)
    team_name = {tid: t["name"] for tid, t in E["teams"].items()}
    rows = []
    for x in raw:
        pl = x["player"]
        name = pl["fullName"]
        pr = proj.get(L.norm(name)) or L.fallback_projection(name)
        u = (L.sigma_units(pr["r"]) - FA.U0) if pr is not None else None
        tid = x.get("onTeamId")
        rows.append({"id": x["id"], "name": name, "team": L.tri(PRO_TEAM_MAP.get(pl.get("proTeamId"), "FA")),
                     "owner": team_name.get(tid, ""), "own": round(pl.get("ownership", {}).get("percentOwned", 0.0), 1),
                     "inj": pl.get("injuryStatus", "ACTIVE"), "espn_rank": ranks.get(x["id"]),
                     "our": [round(float(v), 2) for v in u] if u is not None else None,
                     "our_tot": round(float(u.sum()), 2) if u is not None else None, "pg": _pg(pr["r"]) if pr is not None else None,
                     "elig": [L.POS_ID[s] for s in pl.get("eligibleSlots", []) if s in L.POS_ID]})
    proj_rows = [r for r in rows if r["our"] is not None]
    for k, r in enumerate(sorted(proj_rows, key=lambda r: -r["our_tot"])):
        r["our_rank"] = k + 1
    for r in rows:
        r.setdefault("our_rank", None)
        r["d_rank"] = (r["espn_rank"] - r["our_rank"]) if (r["espn_rank"] and r["our_rank"]) else None
    out = sorted(rows, key=lambda r: (r["espn_rank"] is None, r["espn_rank"] or 0, r["our_rank"] or 9999))
    both = [r for r in out if r["d_rank"] is not None]
    rho = None
    if len(both) > 10:
        a = np.argsort(np.argsort([r["espn_rank"] for r in both])); b = np.argsort(np.argsort([r["our_rank"] for r in both]))
        rho = float(np.corrcoef(a, b)[0, 1])
    rater = {"cats": [L.LABEL[c] for c in L.CATS], "keys": list(L.CATS), "rows": [{k: v for k, v in r.items() if k != "pg"} for r in out],
             "mode": mode, "espn_label": label, "n_espn": len(ranks), "n_ours": len(proj_rows), "rank_corr": rho,
             "no_model": sum(1 for r in out if r["our"] is None)}
    byid = {r["id"]: r for r in out}
    rost = {}
    for tid, t in E["teams"].items():
        lst = []
        for p in t["roster"]:
            d = byid.get(p["id"])
            lst.append(d if d else {"id": p["id"], "name": p["name"], "team": p["team"], "inj": p["inj"], "elig": [], "pg": None, "our_tot": None,
                                    "espn_rank": None, "our_rank": None})
        lst.sort(key=lambda d: (d["our_rank"] is None, d["our_rank"] or 0))
        rost[str(tid)] = [{k: d.get(k) for k in ("id", "name", "team", "inj", "elig", "pg", "our_tot", "espn_rank", "our_rank")} for d in lst]
    return rater, rost
