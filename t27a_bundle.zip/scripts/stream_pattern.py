"""Streaming habits of every manager in a league, learned from the move log, and a forecast of what the opponent will still do this week.

Input = the move log the apps already keep (`moves_log.json`, one event per team per refresh with who came in / went out; roster diffs, because
ESPN's and Yahoo's transaction lists need a login). Each event only says "between `since` and `ts`", so its weight is spread evenly over that window
(a 40-minute window pins a day and an hour; a 3-day window blurs them and counts for little in the hour/day profile).

Per team (profile): adds per week as a share of the weekly allowance (shrunk toward the league mean), which weekdays and hours they act on
(shrunk toward the league pattern), how long a pick-up is held before it is dropped again (streamer share = dropped within ~3.5 days), which
categories their moves tried to fix, and whether the players they add have more games in the next 3 days than an average team (schedule-driven).
Forecast: expected adds still to come this week = weekly rate x the share of their usual action days that remain, chance of at least one more add,
how many swaps to model, and the day the next one most likely lands (the opponent model gives the added player that start date).

Limits: a few weeks of data at most this early in the season (confidence label says how thin); a move is only seen when the app refreshed
after it, and an add that was dropped between two refreshes is invisible; trades are excluded; hold times of players still on the roster are
unknown (censored). Shrinkage constant k is estimated from the data once 3+ full weeks exist, otherwise 2.
"""
import json
import math
import re
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

try:
    from zoneinfo import ZoneInfo
    _ET = ZoneInfo("America/New_York")
except Exception:                                   # no tz database on this machine: EDT/EST by calendar month
    _ET = None

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
MAX_WINDOW_H = 7 * 24
SHORT_HOLD = 3.5            # days: a pick-up dropped within this is a "streamer"


def parse_ts(s):
    """'2026-10-15 07:44 UTC' or '2026-10-27T12:56:31.889Z' -> aware UTC datetime (None if unreadable)."""
    if not s:
        return None
    s = str(s).strip().replace("UTC", "").strip()
    try:
        d = datetime.fromisoformat(s.replace("Z", "+00:00").replace(" ", "T"))
    except ValueError:
        return None
    return d.replace(tzinfo=timezone.utc) if d.tzinfo is None else d.astimezone(timezone.utc)


def to_et(d):
    if _ET is not None:
        return d.astimezone(_ET)
    return d + timedelta(hours=-4 if 3 <= d.month <= 10 else -5)


def load_log(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except Exception:
        return []


def merge_logs(*logs):
    """Union of several copies of a move log (local file + the cloud copy), de-duplicated on (team, ts, in, out), newest first."""
    seen, out = set(), []
    for lg in logs:
        for e in lg or []:
            key = (e.get("team_id"), str(e.get("ts")), tuple(sorted(e.get("in", []))), tuple(sorted(e.get("out", []))))
            if key not in seen:
                seen.add(key)
                out.append(e)
    out.sort(key=lambda e: parse_ts(e.get("ts")) or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    return out


def fetch_remote_log(repo, branch="state", sub="live", timeout=15):
    """The cloud copy of the log (public repo, state branch) - it is refreshed every ~10 minutes, a local copy only while the app runs."""
    import urllib.request
    url = f"https://raw.githubusercontent.com/{repo}/{branch}/{sub}/moves_log.json".replace("//moves", "/moves")
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8-sig"))
    except Exception:
        return []


def _windows(events):
    """Attach a [start, end] window to every event (its own `since`, else the previous distinct refresh time seen in the log)."""
    stamps = sorted({parse_ts(e.get("ts")) for e in events if parse_ts(e.get("ts"))})
    prev = {t: (stamps[i - 1] if i else None) for i, t in enumerate(stamps)}
    out = []
    for e in events:
        end = parse_ts(e.get("ts"))
        if not end:
            continue
        start = parse_ts(e.get("since")) or prev.get(end) or end - timedelta(hours=24)
        if start >= end:
            start = end - timedelta(minutes=30)
        if (end - start).total_seconds() / 3600 > MAX_WINDOW_H:
            start = end - timedelta(hours=MAX_WINDOW_H)
        out.append((e, start, end))
    return out


def _spread(start, end):
    """[(weight, ET datetime)] hourly points across the window, weights sum to 1."""
    n = max(1, int(math.ceil((end - start).total_seconds() / 3600)))
    pts = [to_et(start + (end - start) * ((i + 0.5) / n)) for i in range(n)]
    return [(1.0 / n, p) for p in pts]


def _day_idx_nba(et):
    """First game day a move at this ET time can help: the date 5 h later (a 3am-ET waiver run serves that day's games, an 11pm move the next day's).
    Seen 2026-10: most adds land in the ~3am-ET processing run (claims placed earlier), so the clock hour says when ESPN ran, not when the manager decided;
    the weekday is the signal."""
    return (et + timedelta(hours=5)).date()


def _is_claim_run(et):
    return 2 <= et.hour < 6


def build(events, week_of, limit_of, cur_week, hist=None, games_fn=None, edge_ref=None, first_week=1):
    """events: move log. week_of(date)->matchup period or None; limit_of(mp)->add allowance; cur_week: period in progress;
    hist: {team_id: {mp: adds used}} from the site counter (authoritative for finished weeks); games_fn(player, date)->(games in his next 3 days minus the league-average team's) or None; edge_ref=0.0 switches the schedule edge on."""
    wins = _windows(events)
    teams = {}
    adds_by_week = defaultdict(lambda: defaultdict(int))                    # team -> mp -> adds seen in the log
    dow_w, hr_w = defaultdict(lambda: [0.0] * 7), defaultdict(lambda: [0.0] * 24)
    ev_dow = []                                                             # (team, weekday weights of one event, adds in it)
    claim = defaultdict(float)                                              # adds that landed in the processing run
    adds = defaultdict(list)                                                # team -> [(player, mid-time, week)]
    outs = defaultdict(list)                                                # team -> [(player, mid-time)]
    cats = defaultdict(lambda: defaultdict(float))
    edge = defaultdict(list)
    for e, a, b in sorted(wins, key=lambda x: x[2]):
        tid = e.get("team_id")
        teams.setdefault(tid, e.get("team") or str(tid))
        mid = a + (b - a) / 2
        for p in e.get("out", []):
            outs[tid].append((p, mid))
        if e.get("kind") == "TRADE":
            continue
        n_in = len(e.get("in", []))
        if not n_in:
            continue
        pts = _spread(a, b)
        mp = week_of(_day_idx_nba(pts[len(pts) // 2][1]))
        if mp is None or mp < first_week:
            continue
        adds_by_week[tid][mp] += n_in
        v = [0.0] * 7
        for w, et in pts:
            v[_day_idx_nba(et).weekday()] += w
        ev_dow.append((tid, v, n_in))
        for w, et in pts:
            dow_w[tid][_day_idx_nba(et).weekday()] += w * n_in
            hr_w[tid][et.hour] += w * n_in
            claim[tid] += w * n_in * _is_claim_run(et)
        for p in e.get("in", []):
            adds[tid].append((p, mid, mp))
        for c in e.get("cats", []) or []:
            if c.get("rank_to", 0) < c.get("rank_from", 0) and c.get("dz", 0) > 0:
                cats[tid][c["cat"]] += c["dz"] * n_in / max(1, len(e.get("in", [])))
        if games_fn:
            for p in e.get("in", []):
                try:
                    g = games_fn(p, _day_idx_nba(to_et(mid)))
                except Exception:
                    g = None
                if g is not None:
                    edge[tid].append(g)
    # ---- weekly use as a share of the allowance, finished weeks only
    frac = {}
    for tid in teams:
        h = (hist or {}).get(tid, {})
        by = {}
        for mp in range(first_week, cur_week):
            used = h.get(mp)
            if used is None:
                used = adds_by_week[tid].get(mp, 0) if mp >= _first_logged_week(adds_by_week, wins, week_of) else None
            if used is not None:
                by[mp] = min(1.0, used / float(limit_of(mp)))
        frac[tid] = by
    allf = [v for by in frac.values() for v in by.values()]
    n_w = max((len(by) for by in frac.values()), default=0)
    mu = (sum(allf) / len(allf)) if allf else 0.5
    k = _estimate_k(frac) if n_w >= 3 and len(frac) >= 4 else 2.0
    dow_m = _choose_smooth(ev_dow)
    league_dow = [sum(dow_w[t][i] for t in teams) for i in range(7)]
    ld_tot = sum(league_dow) or 1.0
    league_share = [x / ld_tot for x in league_dow]
    # ---- hold times
    prof = {}
    for tid, name in teams.items():
        by = frac[tid]
        rate = (sum(by.values()) + mu * k) / (len(by) + k)
        raw = dow_w[tid]
        tot = sum(raw)
        share = [(raw[i] + dow_m * league_share[i]) / (tot + dow_m) for i in range(7)]
        hours = hr_w[tid]
        league_claim = sum(claim.values()) / (sum(sum(h) for h in hr_w.values()) or 1.0)
        claim_share = (claim[tid] + 2 * league_claim) / (sum(hours) + 2)
        holds, short, resolved, old_open = [], 0, 0, 0
        now = max((w[2] for w in wins), default=None)
        for p, t_in, _mp in adds[tid]:
            t_out = next((t for q, t in sorted(outs[tid], key=lambda x: x[1]) if q == p and t > t_in), None)
            if t_out is not None:
                d = (t_out - t_in).total_seconds() / 86400
                holds.append(d)
                resolved += 1
                short += d <= SHORT_HOLD
            elif now is not None and (now - t_in).total_seconds() / 86400 > SHORT_HOLD:
                old_open += 1
        n_add = len(adds[tid])
        fav = sorted(range(7), key=lambda i: -share[i])
        fav_days = [DAYS[i] for i in fav[:2] if share[i] >= 1.3 / 7] if (n_add >= 3 and dow_m <= 32) else []
        top_cats = [c for c, _ in sorted(cats[tid].items(), key=lambda kv: -kv[1])[:3]]
        conf = "solid" if n_add >= 12 and len(by) >= 3 else ("fair" if n_add >= 5 else "thin")
        prof[tid] = {"id": tid, "name": name, "n_adds": n_add, "weeks_seen": len(by), "weekly_frac": float(rate),
                     "raw_frac": (sum(by.values()) / len(by)) if by else None, "dow": [float(x) for x in share],
                     "dow_raw": [round(float(x), 2) for x in raw], "fav_days": fav_days, "claim_share": float(claim_share),
                     "hold_median": float(sorted(holds)[len(holds) // 2]) if holds else None, "n_resolved": resolved,
                     "streamer_share": float(short / (resolved + old_open)) if (resolved + old_open) >= 3 else None,
                     "cats": top_cats, "sched_edge": (float(sum(edge[tid]) / len(edge[tid]) - (edge_ref or 0.0)) if len(edge[tid]) >= 3 and edge_ref is not None else None),
                     "conf": conf, "adds_by_week": {int(m): int(v) for m, v in sorted(adds_by_week[tid].items())}}
    league = {"mean_frac": float(mu), "k": float(k), "weeks": n_w, "dow": [float(x) for x in league_share], "n_adds": int(sum(len(v) for v in adds.values())),
              "n_teams": len(teams), "dow_smooth": float(dow_m), "dow_habit": bool(dow_m <= 32), "claim_share": float(sum(claim.values()) / (sum(sum(h) for h in hr_w.values()) or 1.0))}
    return prof, league


def _first_logged_week(adds_by_week, wins, week_of):
    """First matchup period the log covers (a period before it has no log counts, so it must not count as 'zero adds')."""
    first = min((w[1] for w in wins), default=None)
    if first is None:
        return 10 ** 6
    return week_of(_day_idx_nba(to_et(first))) or 1


def _choose_smooth(ev_dow, grid=(2.0, 4.0, 8.0, 16.0, 32.0, 64.0, 1e9)):
    """How hard to pull a team's weekday shares toward the league pattern: the grid value with the best leave-one-event-out log score
    (predict the weekdays of each event from all the OTHER events). 1e9 = league pattern only. On 2026-10 data (81 adds) the league pattern
    won outright: individual weekday habits were not yet predictive, so the forecast leans on the pooled pattern until they are."""
    if len(ev_dow) < 20:
        return 1e9
    tot = defaultdict(lambda: [0.0] * 7)
    for tid, v, n in ev_dow:
        for i in range(7):
            tot[tid][i] += v[i] * n
    lg = [sum(tot[t][i] for t in tot) for i in range(7)]
    best, best_ll = 1e9, -1e18
    for m in grid:
        ll = 0.0
        for tid, v, n in ev_dow:
            c = [tot[tid][i] - v[i] * n for i in range(7)]
            L = [lg[i] - v[i] * n for i in range(7)]
            cs, Ls = sum(c), sum(L)
            if Ls <= 0:
                continue
            for i in range(7):
                if v[i] > 0:
                    p = (c[i] + m * L[i] / Ls) / (cs + m) if m < 1e8 else L[i] / Ls
                    ll += n * v[i] * math.log(max(p, 1e-6))
        if ll > best_ll + 1e-9:
            best, best_ll = m, ll
    return best


def _estimate_k(frac):
    """Shrinkage constant = within-team variance / between-team variance of the weekly share (method of moments), clipped to [0.5, 8]."""
    means, wv, n = [], [], 0
    for by in frac.values():
        if len(by) >= 2:
            v = list(by.values())
            m = sum(v) / len(v)
            means.append(m)
            wv.append(sum((x - m) ** 2 for x in v) / (len(v) - 1))
            n += len(v)
    if len(means) < 3:
        return 2.0
    mm = sum(means) / len(means)
    between = sum((x - mm) ** 2 for x in means) / (len(means) - 1)
    within = sum(wv) / len(wv)
    avg_n = n / len(means)
    tau2 = max(1e-4, between - within / avg_n)
    return float(min(8.0, max(0.5, within / tau2)))


def forecast(prof, league, start, n_days, today_idx, adds_left, limit, adds_used, now_et, fallback_frac=0.5):
    """What `prof` (a team profile) will probably still do this week.
    Returns lam_rem (expected adds still to come), p_any, swaps (how many swaps to model), next_idx (day index of the most likely next add),
    day_adds (expected adds per remaining day), exp_week (expected total this week), conf weight."""
    if not prof:
        return {"lam_rem": fallback_frac * adds_left, "p_any": fallback_frac, "swaps": 3 if adds_left else 0, "next_idx": today_idx,
                "day_adds": {}, "exp_week": fallback_frac * limit, "weight": 0.0, "pattern": False}
    share = prof["dow"]
    ld = league["dow"]
    days = [(start + timedelta(days=i)) for i in range(n_days)]
    w = [share[d.weekday()] for d in days]
    # today is partly gone: once the ~3am-ET claim run has happened, only instant free-agent adds (1 - claim share) can still land, over the rest of the day
    today_left = 1.0
    if now_et is not None and today_idx < n_days and now_et.hour >= 6:
        today_left = max(0.1, (1.0 - prof.get("claim_share", 0.5)) * (0.7 if now_et.hour < 18 else 0.35))
    wt = [x * (today_left if i == today_idx else 1.0) if i >= today_idx else 0.0 for i, x in enumerate(w)]
    tot_all = sum(w) or 1.0
    rem_share = sum(wt) / tot_all
    exp_week = prof["weekly_frac"] * limit
    lam_rem = min(float(adds_left), exp_week * rem_share)
    lam_rem = max(0.0, lam_rem)
    p_any = 1.0 - math.exp(-lam_rem) if adds_left > 0 else 0.0
    swaps = 0 if adds_left <= 0 or p_any < 0.15 else int(min(3, max(1, round(lam_rem)), adds_left))
    wsum = sum(wt) or 1.0
    day_adds = {i: float(lam_rem * wt[i] / wsum) for i in range(today_idx, n_days) if wt[i] > 0}
    nxt = max(day_adds, key=lambda i: day_adds[i]) if day_adds else today_idx
    # the next add is the EARLIEST likely day, not the biggest day: first remaining day holding >= 35% of the single-add chance
    cum, first = 0.0, nxt
    for i in sorted(day_adds):
        cum += day_adds[i]
        if cum >= 0.35 * max(lam_rem, 1e-9):
            first = i
            break
    n_eff = prof["weeks_seen"] + prof["n_adds"] / 4.0
    weight = float(n_eff / (n_eff + 2.0))
    return {"lam_rem": float(lam_rem), "p_any": float(p_any), "swaps": swaps, "next_idx": int(first), "day_adds": day_adds,
            "exp_week": float(exp_week), "weight": weight, "pattern": True, "rem_share": float(rem_share)}


def view(prof, league, mine=None, week_start=None):
    """Compact rows for the page: one per team, readable text, sorted by adds per week."""
    rows = []
    for tid, p in prof.items():
        sd = p["dow"]
        rows.append({"id": tid, "name": p["name"], "is_me": tid == mine, "adds_per_week_frac": p["weekly_frac"], "n_adds": p["n_adds"],
                     "weeks_seen": p["weeks_seen"], "fav_days": p["fav_days"], "dow": [round(x, 3) for x in sd], "claim_share": p["claim_share"],
                     "hold_median": p["hold_median"], "streamer_share": p["streamer_share"], "cats": p["cats"], "sched_edge": p["sched_edge"],
                     "conf": p["conf"], "adds_by_week": p["adds_by_week"]})
    rows.sort(key=lambda r: -r["adds_per_week_frac"])
    return {"rows": rows, "league": {k: league[k] for k in ("mean_frac", "k", "weeks", "dow", "n_adds", "n_teams", "claim_share")}, "days": DAYS}


if __name__ == "__main__":                                  # quick look: python stream_pattern.py <moves_log.json> [limit]
    import sys
    lg = load_log(sys.argv[1])
    lim = int(sys.argv[2]) if len(sys.argv) > 2 else 7
    s0 = date(2026, 10, 20)

    def wk_of(d):
        if d < s0:
            return None
        return 1 if d <= date(2026, 10, 25) else 2 + (d - date(2026, 10, 26)).days // 7
    pr, lgm = build(lg, wk_of, lambda mp: 6 if mp == 1 else lim, 2)
    print({k: lgm[k] for k in ("mean_frac", "k", "weeks", "n_adds", "claim_share")}, [round(x, 2) for x in lgm["dow"]])
    for p in sorted(pr.values(), key=lambda p: -p["weekly_frac"]):
        print(f"{p['name'][:22]:22s} adds={p['n_adds']:2d} frac={p['weekly_frac']:.2f} days={p['fav_days']} claim={p['claim_share']:.2f} hold={p['hold_median']} str={p['streamer_share']} cats={p['cats']} {p['conf']} wk={p['adds_by_week']}")
