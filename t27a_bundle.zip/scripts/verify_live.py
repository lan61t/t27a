"""Live check: does the app read ESPN correctly once real games exist?

    python scripts/verify_live.py              (prints the report; exit code 1 on a mismatch)
    check(lg)                                  (used by build_site.py: runs in the cloud on every build and is published as data/verify.json)

For every finished day of the current matchup it rebuilds what ESPN SHOULD show for your team from the public box scores (the players in
your starting slots that day who played > 0 minutes) and compares it with ESPN's own matchup totals: points, rebounds split, assists, steals,
blocks, turnovers, fouls, FG/FT/3P makes and attempts, and GP (the number the weekly cap is counted on). Statuses:
  waiting  the matchup has no finished day yet (nothing to compare)
  pass     every total matches
  fail     at least one total differs: the MISMATCH line names the statistic
"""
import sys
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import inseason_live as L  # noqa: E402
import espn_site as ES  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

MAP = {"PTS": "PTS", "STL": "STL", "BLK": "BLK", "AST": "AST", "TO": "TOV", "PF": "PF", "FGM": "FGM", "FGA": "FGA", "FTM": "FTM", "FTA": "FTA",
       "3PM": "FG3M", "3PA": "FG3A", "OREB": "OREB", "DREB": "DREB"}
BENCH = {"BE", "IR", None, ""}


def check(lg=None):
    now, today = L.now_nba()
    ran = now.strftime("%Y-%m-%d %H:%M UTC")
    if today < L.SEASON_START:
        return {"status": "waiting", "ran_at": ran, "problems": 0, "lines": [f"The season starts {L.SEASON_START}; nothing to compare yet."]}
    mp = L.period_of(today)
    start, _ = L.period_bounds(mp)
    if lg is None:
        lg = L.LC.open_league()
    lines, problems = [], 0
    tot_exp, gp_exp, days_checked = {k: 0.0 for k in MAP.values()}, 0, 0
    d = start
    while d <= today:
        sp = (d - L.SEASON_START).days + 1
        res = ES.box_lines(d)
        if not res["lines"] or not res["all_final"]:
            d += timedelta(days=1)
            continue
        by_name = {L.norm(x["PLAYER_NAME"]): x for x in res["lines"]}
        mine = None
        for b in lg.box_scores(matchup_period=mp, scoring_period=sp, matchup_total=False):
            for side in ("home", "away"):
                if getattr(b, f"{side}_team").team_id == L.MY_TEAM:
                    mine = getattr(b, f"{side}_lineup")
        if mine is None:
            lines.append(f"{d}: could not read your lineup from ESPN")
            problems += 1
            d += timedelta(days=1)
            continue
        played = [by_name[L.norm(p.name)] for p in mine if p.lineupSlot not in BENCH and L.norm(p.name) in by_name and by_name[L.norm(p.name)]["MIN"] > 0]
        for k in tot_exp:
            tot_exp[k] += sum(x[k] for x in played)
        gp_exp += len(played)
        days_checked += 1
        lines.append(f"{d}: {len(played)} of your starters played")
        d += timedelta(days=1)
    if not days_checked:
        return {"status": "waiting", "ran_at": ran, "problems": 0, "lines": ["No finished day with games in this matchup yet."]}
    espn = None
    for b in lg.box_scores(matchup_period=mp, matchup_total=True):
        for side, stats in (("home", b.home_stats), ("away", b.away_stats)):
            if getattr(b, f"{side}_team").team_id == L.MY_TEAM:
                espn = stats
    gp = espn.get("GP", {}).get("value")
    if not gp and gp_exp:                  # ESPN posts a finished day's stats hours after the games (seen 2026-10-21: still 0 nine hours later)
        lines.append("ESPN has not posted these days to the matchup yet (all its totals are 0); nothing to compare until it does.")
        return {"status": "waiting", "ran_at": ran, "problems": 0, "days_checked": days_checked, "lines": lines}
    ok = gp == gp_exp
    problems += 0 if ok else 1
    lines.append(f"{'PASS' if ok else 'MISMATCH'}  GP (counted starts): ESPN {gp} vs expected {gp_exp}")
    for e, k in MAP.items():
        v = espn.get(e, {}).get("value")
        ok = v is not None and abs(v - tot_exp[k]) < 0.5
        problems += 0 if ok else 1
        lines.append(f"{'PASS' if ok else 'MISMATCH'}  {e}: ESPN {v} vs expected {tot_exp[k]:.0f}")
    return {"status": "pass" if not problems else "fail", "ran_at": ran, "problems": problems, "days_checked": days_checked, "lines": lines}


def main():
    r = check()
    print("\n".join(r["lines"]))
    print(f"\n{r['status'].upper()}" + (f" ({r['problems']} problem(s))" if r["problems"] else ""))
    return 1 if r["status"] == "fail" else 0


if __name__ == "__main__":
    sys.exit(main())
