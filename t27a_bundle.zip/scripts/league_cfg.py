"""Per-league settings for the in-season engine. Pick the league with the LEAGUE environment variable (default: lapis).

    LEAGUE=t27a python scripts/build_site.py --out site

Everything that differs between the ESPN leagues lives here, so the engine, the allocator and the page share one code base:
  lapis  New Lapis Lapis League   14 teams, 7 starters, 33 (+7 Sunday) games cap, public
  t27a   CC - T27A                 8 teams, 10 starters (PG SG SF PF C G F UTIL x3), NO games cap, private (needs ESPN login cookies)
Private leagues read ESPN_S2 and ESPN_SWID from the environment (GitHub Actions secrets in the cloud, never stored in the code).
"""
import json
import os
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SEASON_START = date(2026, 10, 20)
SEASON_END = date(2027, 4, 11)


def _lapis_period(mp):
    """Week 1 = Tue Oct 20 - Sun Oct 25, weeks 2-17 Mon-Sun from Oct 26, week 18 = Feb 15-28 (All-Star, two weeks), then one-week playoff rounds."""
    if mp == 1:
        return date(2026, 10, 20), date(2026, 10, 25)
    if mp <= 17:
        s = date(2026, 10, 26) + timedelta(days=7 * (mp - 2))
        return s, s + timedelta(days=6)
    if mp == 18:
        return date(2027, 2, 15), date(2027, 2, 28)
    s = date(2027, 3, 1) + timedelta(days=7 * (mp - 19))
    return s, min(s + timedelta(days=6), SEASON_END)


def _t27a_period(mp):
    """Read from ESPN's schedule page 2026-10-20: matchups 1-17 as Lapis, 18 = Feb 15-28, 19 = Mar 1-7, Round 1 = Mar 8-21, Round 2 = Mar 22-Apr 4."""
    if mp <= 18:
        return _lapis_period(mp)
    if mp == 19:
        return date(2027, 3, 1), date(2027, 3, 7)
    if mp == 20:
        return date(2027, 3, 8), date(2027, 3, 21)
    return date(2027, 3, 22), date(2027, 4, 4)


LEAGUES = {
    "lapis": {
        "key": "lapis", "name": "New Lapis Lapis League", "title": "Lapis Daily", "short": "Lapis",
        "league_id": 127741, "year": 2027, "my_team": 1, "n_teams": 14, "private": False,
        "slots": ["PG", "SG", "SF", "PF", "C", "UTIL", "UTIL"], "bench": 5, "ir": 0,
        "cap": 33, "sun_cap": 7, "week_cap": {1: 28}, "long_weeks": [18], "n_periods": 24,
        "adds": 7, "week_adds": {1: 6}, "period_fn": _lapis_period,
        "repo": "lan61t/themob", "site": "https://lan61t.github.io/themob/",
        "live_dir": "",                      # keeps the existing data/live/ paths
        "trade_deadline": "2027-03-01", "playoff_teams": 8,
    },
    "t27a": {
        "key": "t27a", "name": "CC - T27A", "title": "T27A Daily", "short": "T27A",
        "league_id": 1106068223, "year": 2027, "my_team": 1, "n_teams": 8, "private": True,
        "slots": ["PG", "SG", "SF", "PF", "C", "G", "F", "UTIL", "UTIL", "UTIL"], "bench": 3, "ir": 1,
        "cap": None, "sun_cap": None, "week_cap": {}, "long_weeks": [18, 20, 21], "n_periods": 21,
        "adds": 7, "week_adds": {1: 6, 18: 14, 20: 14, 21: 14}, "period_fn": _t27a_period,
        "repo": "lan61t/t27a", "site": "https://lan61t.github.io/t27a/",
        "live_dir": "t27a",
        "trade_deadline": "2027-02-20", "playoff_teams": 4,
    },
}

KEY = os.environ.get("LEAGUE", "lapis").strip().lower()
if KEY not in LEAGUES:
    raise SystemExit(f"unknown LEAGUE '{KEY}' (known: {', '.join(LEAGUES)})")
C = LEAGUES[KEY]

LEAGUE_ID, YEAR, MY_TEAM = C["league_id"], C["year"], C["my_team"]
SLOTS = list(C["slots"])
HAS_CAP = C["cap"] is not None
LIVE = ROOT / "data" / "live" / C["live_dir"] if C["live_dir"] else ROOT / "data" / "live"      # league-specific state (snapshots, move log, predictions)
REPLAY = Path(os.environ["ESPN_REPLAY"]) if os.environ.get("ESPN_REPLAY") else None            # offline fixtures of ESPN answers (local testing of a private league)


def cookies():
    """ESPN login cookies for a private league: from the environment only."""
    s2, swid = os.environ.get("ESPN_S2", "").strip(), os.environ.get("ESPN_SWID", "").strip()
    return {"espn_s2": s2, "SWID": swid} if s2 and swid else None


def replay_key(extend, params, headers):
    import hashlib
    f = (headers or {}).get("x-fantasy-filter")
    blob = json.dumps({"e": extend or "", "p": params or {}, "f": json.loads(f) if f else None}, sort_keys=True, default=str)
    return hashlib.sha1(blob.encode()).hexdigest()[:16]


def open_league():
    """espn_api League for this league: live (with cookies when private) or from recorded fixtures when ESPN_REPLAY is set."""
    from espn_api.basketball import League
    from espn_api.requests import espn_requests as R
    if REPLAY is not None and not getattr(R.EspnFantasyRequests, "_replay_patched", False):
        orig = R.EspnFantasyRequests.league_get

        def league_get(self, params=None, headers=None, extend=""):
            f = REPLAY / f"{replay_key(extend, params, headers)}.json"
            if f.exists():
                r = json.loads(f.read_text(encoding="utf-8"))
                return r[0] if isinstance(r, list) else r
            need = REPLAY / "_needed.jsonl"
            with open(need, "a", encoding="utf-8") as fh:
                fh.write(json.dumps({"key": replay_key(extend, params, headers), "extend": extend or "", "params": params, "filter": (headers or {}).get("x-fantasy-filter")}) + "\n")
            raise R.ESPNUnknownError(f"no recorded answer for {params} {extend} (key {replay_key(extend, params, headers)})")

        R.EspnFantasyRequests.league_get = league_get
        R.EspnFantasyRequests._replay_patched = True
    ck = cookies()
    if ck:
        return League(league_id=LEAGUE_ID, year=YEAR, espn_s2=ck["espn_s2"], swid=ck["SWID"])
    return League(league_id=LEAGUE_ID, year=YEAR)
